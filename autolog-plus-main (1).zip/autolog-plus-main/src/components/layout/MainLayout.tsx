import { ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useUserRole } from "@/hooks/useRoles";
import { Button } from "@/components/ui/button";
import { 
  Car, 
  LayoutDashboard, 
  Bell, 
  Settings, 
  LogOut,
  Menu,
  X,
  Plus,
  Wrench,
  Calendar,
  ShieldCheck,
  ShoppingBag
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface MainLayoutProps {
  children: ReactNode;
}

const userNavItems = [
  { path: "/", label: "الرئيسية", icon: LayoutDashboard },
  { path: "/cars", label: "سياراتي", icon: Car },
  { path: "/marketplace", label: "السوق", icon: ShoppingBag },
  { path: "/workshops", label: "الورشات", icon: Wrench },
  { path: "/alerts", label: "التنبيهات", icon: Bell },
];

const workshopNavItems = [
  { path: "/workshop/dashboard", label: "لوحة التحكم", icon: LayoutDashboard },
  { path: "/workshop/bookings", label: "الحجوزات", icon: Calendar },
  { path: "/settings", label: "الإعدادات", icon: Settings },
];

const adminNavItems = [
  { path: "/admin", label: "لوحة الأدمن", icon: ShieldCheck },
  { path: "/admin/alerts", label: "التنبيهات", icon: Bell },
  { path: "/admin/listings", label: "إعلانات السيارات", icon: ShoppingBag },
  { path: "/workshops", label: "الورشات", icon: Wrench },
];

export default function MainLayout({ children }: MainLayoutProps) {
  const { signOut } = useAuth();
  const { data: userRole } = useUserRole();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Choose nav items based on role
  const navItems = userRole?.role === "admin" 
    ? adminNavItems 
    : userRole?.role === "workshop" 
      ? workshopNavItems 
      : userNavItems;
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/95 backdrop-blur border-b">
        <div className="container flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
              <Car className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg hidden sm:block">سيارتي</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link key={item.path} to={item.path}>
                  <Button
                    variant={isActive ? "default" : "ghost"}
                    size="sm"
                    className="gap-2"
                  >
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </Button>
                </Link>
              );
            })}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <Link to="/cars/new" className="hidden sm:block">
              <Button size="sm" className="gap-2">
                <Plus className="w-4 h-4" />
                <span className="hidden lg:inline">إضافة سيارة</span>
              </Button>
            </Link>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => signOut()}
              className="hidden md:flex"
              title="تسجيل الخروج"
            >
              <LogOut className="w-4 h-4" />
            </Button>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t bg-card animate-slide-in-up">
            <nav className="container py-4 space-y-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <Button
                      variant={isActive ? "default" : "ghost"}
                      className="w-full justify-start gap-3"
                    >
                      <Icon className="w-5 h-5" />
                      {item.label}
                    </Button>
                  </Link>
                );
              })}
              <hr className="my-2" />
              <Link to="/cars/new" onClick={() => setMobileMenuOpen(false)}>
                <Button className="w-full justify-start gap-3">
                  <Plus className="w-5 h-5" />
                  إضافة سيارة جديدة
                </Button>
              </Link>
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 text-destructive hover:text-destructive"
                onClick={() => {
                  setMobileMenuOpen(false);
                  signOut();
                }}
              >
                <LogOut className="w-5 h-5" />
                تسجيل الخروج
              </Button>
            </nav>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="container py-6 pb-20 md:pb-6">
        {children}
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-card border-t z-50">
        <div className="flex justify-around items-center h-16">
          {navItems.slice(0, 4).map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex flex-col items-center gap-1 p-2 rounded-lg transition-colors",
                  isActive ? "text-primary" : "text-muted-foreground"
                )}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs">{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

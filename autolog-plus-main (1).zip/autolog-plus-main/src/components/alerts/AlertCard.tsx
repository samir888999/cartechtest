import { Alert, alertTypeLabels, alertTypeIcons, getAlertStatus } from "@/hooks/useAlerts";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Trash2, Calendar, Gauge } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

interface AlertCardProps {
  alert: Alert & { cars?: { brand: string; model: string; plate_number: string | null } };
  currentMileage?: number;
  onComplete?: (id: string) => void;
  onDelete?: (id: string) => void;
  showCarInfo?: boolean;
}

export default function AlertCard({
  alert,
  currentMileage,
  onComplete,
  onDelete,
  showCarInfo = false,
}: AlertCardProps) {
  const status = getAlertStatus(alert, currentMileage);
  const icon = alertTypeIcons[alert.alert_type];
  const label = alert.custom_title || alertTypeLabels[alert.alert_type];

  return (
    <Card
      className={cn(
        "transition-all duration-200",
        status === "overdue" && "border-destructive/50 bg-destructive/5",
        status === "warning" && "border-warning/50 bg-warning/5"
      )}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          {/* Icon */}
          <div
            className={cn(
              "w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0",
              status === "overdue" && "bg-destructive/20",
              status === "warning" && "bg-warning/20",
              status === "normal" && "bg-primary/10"
            )}
          >
            {icon}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h4 className="font-semibold">{label}</h4>
                {showCarInfo && alert.cars && (
                  <p className="text-sm text-muted-foreground">
                    {alert.cars.brand} {alert.cars.model}
                    {alert.cars.plate_number && ` - ${alert.cars.plate_number}`}
                  </p>
                )}
              </div>
              <Badge
                variant={
                  status === "overdue"
                    ? "destructive"
                    : status === "warning"
                    ? "outline"
                    : "secondary"
                }
                className={cn(
                  "shrink-0",
                  status === "warning" && "border-warning text-warning"
                )}
              >
                {status === "overdue"
                  ? "متأخر"
                  : status === "warning"
                  ? "قريباً"
                  : "نشط"}
              </Badge>
            </div>

            {/* Trigger info */}
            <div className="flex flex-wrap items-center gap-3 mt-2 text-sm text-muted-foreground">
              {alert.trigger_date && (
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>
                    {format(new Date(alert.trigger_date), "d MMMM yyyy", { locale: ar })}
                  </span>
                </div>
              )}
              {alert.trigger_mileage && (
                <div className="flex items-center gap-1">
                  <Gauge className="w-4 h-4" />
                  <span>{alert.trigger_mileage.toLocaleString()} كم</span>
                </div>
              )}
            </div>

            {alert.description && (
              <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                {alert.description}
              </p>
            )}

            {/* Actions */}
            {(onComplete || onDelete) && (
              <div className="flex items-center gap-2 mt-3">
                {onComplete && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="gap-1 text-success border-success/30 hover:bg-success/10"
                    onClick={() => onComplete(alert.id)}
                  >
                    <Check className="w-4 h-4" />
                    تم
                  </Button>
                )}
                {onDelete && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="gap-1 text-destructive hover:text-destructive hover:bg-destructive/10"
                    onClick={() => onDelete(alert.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                    حذف
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

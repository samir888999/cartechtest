import { Link } from "react-router-dom";
import { Car as CarType } from "@/hooks/useCars";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Car, Gauge, Calendar, ChevronLeft } from "lucide-react";

interface CarCardProps {
  car: CarType;
  alertCount?: number;
}

export default function CarCard({ car, alertCount = 0 }: CarCardProps) {
  return (
    <Link to={`/cars/${car.id}`}>
      <Card className="hover:shadow-card-hover transition-all duration-200 group overflow-hidden">
        <CardContent className="p-0">
          <div className="flex items-stretch">
            {/* Car Image/Icon */}
            <div className="w-24 h-24 sm:w-32 sm:h-32 bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center shrink-0">
              {car.image_url ? (
                <img
                  src={car.image_url}
                  alt={`${car.brand} ${car.model}`}
                  className="w-full h-full object-cover"
                />
              ) : (
                <Car className="w-10 h-10 sm:w-12 sm:h-12 text-primary/50" />
              )}
            </div>

            {/* Car Info */}
            <div className="flex-1 p-4 flex flex-col justify-between min-w-0">
              <div>
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-bold text-lg truncate">
                    {car.brand} {car.model}
                  </h3>
                  {alertCount > 0 && (
                    <Badge variant="destructive" className="shrink-0">
                      {alertCount} تنبيه
                    </Badge>
                  )}
                </div>
                
                {car.plate_number && (
                  <p className="text-sm text-muted-foreground mt-1">
                    {car.plate_number}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{car.year}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Gauge className="w-4 h-4" />
                  <span>{car.current_mileage.toLocaleString()} كم</span>
                </div>
              </div>
            </div>

            {/* Arrow */}
            <div className="flex items-center px-3 text-muted-foreground group-hover:text-primary transition-colors">
              <ChevronLeft className="w-5 h-5" />
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

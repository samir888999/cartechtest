export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      alerts: {
        Row: {
          alert_type: Database["public"]["Enums"]["alert_type"]
          car_id: string
          completed_at: string | null
          created_at: string
          custom_title: string | null
          description: string | null
          id: string
          is_active: boolean
          is_completed: boolean
          remind_days_before: number | null
          remind_km_before: number | null
          trigger_date: string | null
          trigger_mileage: number | null
          trigger_type: Database["public"]["Enums"]["alert_trigger_type"]
          updated_at: string
          user_id: string
        }
        Insert: {
          alert_type: Database["public"]["Enums"]["alert_type"]
          car_id: string
          completed_at?: string | null
          created_at?: string
          custom_title?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          is_completed?: boolean
          remind_days_before?: number | null
          remind_km_before?: number | null
          trigger_date?: string | null
          trigger_mileage?: number | null
          trigger_type?: Database["public"]["Enums"]["alert_trigger_type"]
          updated_at?: string
          user_id: string
        }
        Update: {
          alert_type?: Database["public"]["Enums"]["alert_type"]
          car_id?: string
          completed_at?: string | null
          created_at?: string
          custom_title?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          is_completed?: boolean
          remind_days_before?: number | null
          remind_km_before?: number | null
          trigger_date?: string | null
          trigger_mileage?: number | null
          trigger_type?: Database["public"]["Enums"]["alert_trigger_type"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "alerts_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      bookings: {
        Row: {
          booking_date: string
          booking_time: string
          car_id: string
          created_at: string
          id: string
          notes: string | null
          service_type: string
          status: string
          updated_at: string
          user_id: string
          workshop_id: string
        }
        Insert: {
          booking_date: string
          booking_time: string
          car_id: string
          created_at?: string
          id?: string
          notes?: string | null
          service_type: string
          status?: string
          updated_at?: string
          user_id: string
          workshop_id: string
        }
        Update: {
          booking_date?: string
          booking_time?: string
          car_id?: string
          created_at?: string
          id?: string
          notes?: string | null
          service_type?: string
          status?: string
          updated_at?: string
          user_id?: string
          workshop_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookings_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_workshop_id_fkey"
            columns: ["workshop_id"]
            isOneToOne: false
            referencedRelation: "workshops"
            referencedColumns: ["id"]
          },
        ]
      }
      car_listings: {
        Row: {
          admin_notes: string | null
          approved_at: string | null
          approved_by: string | null
          car_id: string
          contact_phone: string | null
          contact_whatsapp: string | null
          created_at: string
          description: string | null
          id: string
          image_url: string | null
          is_negotiable: boolean | null
          price: number
          status: string
          title: string
          updated_at: string
          user_id: string
          views_count: number | null
        }
        Insert: {
          admin_notes?: string | null
          approved_at?: string | null
          approved_by?: string | null
          car_id: string
          contact_phone?: string | null
          contact_whatsapp?: string | null
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          is_negotiable?: boolean | null
          price: number
          status?: string
          title: string
          updated_at?: string
          user_id: string
          views_count?: number | null
        }
        Update: {
          admin_notes?: string | null
          approved_at?: string | null
          approved_by?: string | null
          car_id?: string
          contact_phone?: string | null
          contact_whatsapp?: string | null
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          is_negotiable?: boolean | null
          price?: number
          status?: string
          title?: string
          updated_at?: string
          user_id?: string
          views_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "car_listings_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      cars: {
        Row: {
          brand: string
          color: string | null
          created_at: string
          current_mileage: number
          fuel_type: string | null
          id: string
          image_url: string | null
          model: string
          plate_number: string | null
          updated_at: string
          user_id: string
          vin_number: string | null
          year: number
        }
        Insert: {
          brand: string
          color?: string | null
          created_at?: string
          current_mileage?: number
          fuel_type?: string | null
          id?: string
          image_url?: string | null
          model: string
          plate_number?: string | null
          updated_at?: string
          user_id: string
          vin_number?: string | null
          year: number
        }
        Update: {
          brand?: string
          color?: string | null
          created_at?: string
          current_mileage?: number
          fuel_type?: string | null
          id?: string
          image_url?: string | null
          model?: string
          plate_number?: string | null
          updated_at?: string
          user_id?: string
          vin_number?: string | null
          year?: number
        }
        Relationships: []
      }
      maintenance_records: {
        Row: {
          car_id: string
          cost: number | null
          created_at: string
          custom_type: string | null
          description: string | null
          id: string
          invoice_url: string | null
          maintenance_type: Database["public"]["Enums"]["maintenance_type"]
          mileage: number
          next_service_date: string | null
          next_service_mileage: number | null
          notes: string | null
          service_date: string
          updated_at: string
          user_id: string
        }
        Insert: {
          car_id: string
          cost?: number | null
          created_at?: string
          custom_type?: string | null
          description?: string | null
          id?: string
          invoice_url?: string | null
          maintenance_type: Database["public"]["Enums"]["maintenance_type"]
          mileage: number
          next_service_date?: string | null
          next_service_mileage?: number | null
          notes?: string | null
          service_date: string
          updated_at?: string
          user_id: string
        }
        Update: {
          car_id?: string
          cost?: number | null
          created_at?: string
          custom_type?: string | null
          description?: string | null
          id?: string
          invoice_url?: string | null
          maintenance_type?: Database["public"]["Enums"]["maintenance_type"]
          mileage?: number
          next_service_date?: string | null
          next_service_mileage?: number | null
          notes?: string | null
          service_date?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "maintenance_records_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string | null
          id: string
          phone: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          phone?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          phone?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      workshop_reviews: {
        Row: {
          comment: string | null
          created_at: string
          id: string
          rating: number
          updated_at: string
          user_id: string
          workshop_id: string
        }
        Insert: {
          comment?: string | null
          created_at?: string
          id?: string
          rating: number
          updated_at?: string
          user_id: string
          workshop_id: string
        }
        Update: {
          comment?: string | null
          created_at?: string
          id?: string
          rating?: number
          updated_at?: string
          user_id?: string
          workshop_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workshop_reviews_workshop_id_fkey"
            columns: ["workshop_id"]
            isOneToOne: false
            referencedRelation: "workshops"
            referencedColumns: ["id"]
          },
        ]
      }
      workshops: {
        Row: {
          address: string | null
          city: string | null
          cover_url: string | null
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          is_verified: boolean
          latitude: number | null
          logo_url: string | null
          longitude: number | null
          name: string
          phone: string | null
          rating_average: number | null
          rating_count: number | null
          services: string[] | null
          updated_at: string
          user_id: string
          working_hours: Json | null
        }
        Insert: {
          address?: string | null
          city?: string | null
          cover_url?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          is_verified?: boolean
          latitude?: number | null
          logo_url?: string | null
          longitude?: number | null
          name: string
          phone?: string | null
          rating_average?: number | null
          rating_count?: number | null
          services?: string[] | null
          updated_at?: string
          user_id: string
          working_hours?: Json | null
        }
        Update: {
          address?: string | null
          city?: string | null
          cover_url?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          is_verified?: boolean
          latitude?: number | null
          logo_url?: string | null
          longitude?: number | null
          name?: string
          phone?: string | null
          rating_average?: number | null
          rating_count?: number | null
          services?: string[] | null
          updated_at?: string
          user_id?: string
          working_hours?: Json | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      alert_trigger_type: "date" | "mileage" | "both"
      alert_type:
        | "oil_change"
        | "tire_change"
        | "brake_service"
        | "insurance_renewal"
        | "technical_inspection"
        | "license_renewal"
        | "general_maintenance"
        | "custom"
      app_role: "user" | "workshop" | "trader" | "admin"
      maintenance_type:
        | "oil_change"
        | "tire_rotation"
        | "tire_replacement"
        | "brake_service"
        | "filter_change"
        | "battery_replacement"
        | "general_service"
        | "inspection"
        | "other"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      alert_trigger_type: ["date", "mileage", "both"],
      alert_type: [
        "oil_change",
        "tire_change",
        "brake_service",
        "insurance_renewal",
        "technical_inspection",
        "license_renewal",
        "general_maintenance",
        "custom",
      ],
      app_role: ["user", "workshop", "trader", "admin"],
      maintenance_type: [
        "oil_change",
        "tire_rotation",
        "tire_replacement",
        "brake_service",
        "filter_change",
        "battery_replacement",
        "general_service",
        "inspection",
        "other",
      ],
    },
  },
} as const

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

export interface CarListing {
  id: string;
  car_id: string;
  user_id: string;
  title: string;
  description: string | null;
  price: number;
  is_negotiable: boolean;
  contact_phone: string | null;
  contact_whatsapp: string | null;
  status: "pending" | "approved" | "rejected" | "sold";
  admin_notes: string | null;
  approved_at: string | null;
  approved_by: string | null;
  views_count: number;
  image_url: string | null;
  created_at: string;
  updated_at: string;
  cars?: {
    id: string;
    brand: string;
    model: string;
    year: number;
    current_mileage: number;
    color: string | null;
    fuel_type: string | null;
    plate_number: string | null;
    image_url: string | null;
  };
}

export interface CreateListingData {
  car_id: string;
  title: string;
  description?: string;
  price: number;
  is_negotiable?: boolean;
  contact_phone?: string;
  contact_whatsapp?: string;
  image_url?: string;
}

// Fetch approved listings for marketplace
export function useMarketplaceListings() {
  return useQuery({
    queryKey: ["marketplace-listings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("car_listings")
        .select("*, cars(*)")
        .eq("status", "approved")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as CarListing[];
    },
  });
}

// Fetch user's own listings
export function useMyListings() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["my-listings", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("car_listings")
        .select("*, cars(*)")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as CarListing[];
    },
    enabled: !!user,
  });
}

// Fetch all listings for admin
export function useAllListings(statusFilter?: string) {
  return useQuery({
    queryKey: ["all-listings", statusFilter],
    queryFn: async () => {
      let query = supabase
        .from("car_listings")
        .select("*, cars(*)")
        .order("created_at", { ascending: false });

      if (statusFilter && statusFilter !== "all") {
        query = query.eq("status", statusFilter);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as CarListing[];
    },
  });
}

// Create a new listing
export function useCreateListing() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (data: CreateListingData) => {
      if (!user) throw new Error("يجب تسجيل الدخول");

      const { data: listing, error } = await supabase
        .from("car_listings")
        .insert({
          ...data,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return listing;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["my-listings"] });
      toast({
        title: "تم الإرسال",
        description: "تم إرسال إعلانك للمراجعة",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Update listing status (admin)
export function useUpdateListingStatus() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async ({
      listingId,
      status,
      adminNotes,
    }: {
      listingId: string;
      status: "approved" | "rejected" | "sold";
      adminNotes?: string;
    }) => {
      const updateData: Record<string, unknown> = {
        status,
        admin_notes: adminNotes,
      };

      if (status === "approved") {
        updateData.approved_at = new Date().toISOString();
        updateData.approved_by = user?.id;
      }

      const { error } = await supabase
        .from("car_listings")
        .update(updateData)
        .eq("id", listingId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["all-listings"] });
      queryClient.invalidateQueries({ queryKey: ["marketplace-listings"] });
      toast({
        title: "تم التحديث",
        description: "تم تحديث حالة الإعلان",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Delete listing
export function useDeleteListing() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (listingId: string) => {
      const { error } = await supabase
        .from("car_listings")
        .delete()
        .eq("id", listingId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["my-listings"] });
      queryClient.invalidateQueries({ queryKey: ["all-listings"] });
      toast({
        title: "تم الحذف",
        description: "تم حذف الإعلان",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

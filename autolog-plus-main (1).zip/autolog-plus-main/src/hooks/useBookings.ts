import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

export type BookingStatus = "pending" | "confirmed" | "completed" | "cancelled";

export interface Booking {
  id: string;
  workshop_id: string;
  user_id: string;
  car_id: string;
  service_type: string;
  booking_date: string;
  booking_time: string;
  status: BookingStatus;
  notes: string | null;
  created_at: string;
  updated_at: string;
  // Joined data
  workshops?: {
    name: string;
    phone: string | null;
    address: string | null;
  };
  cars?: {
    brand: string;
    model: string;
    plate_number: string | null;
  };
}

export interface CreateBookingData {
  workshop_id: string;
  car_id: string;
  service_type: string;
  booking_date: string;
  booking_time: string;
  notes?: string;
}

export function useMyBookings() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["my-bookings", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select(`
          *,
          workshops (name, phone, address),
          cars (brand, model, plate_number)
        `)
        .eq("user_id", user!.id)
        .order("booking_date", { ascending: true });

      if (error) throw error;
      return data as Booking[];
    },
    enabled: !!user,
  });
}

export function useWorkshopBookings(workshopId: string | undefined) {
  return useQuery({
    queryKey: ["workshop-bookings", workshopId],
    queryFn: async () => {
      if (!workshopId) return [];
      const { data, error } = await supabase
        .from("bookings")
        .select(`
          *,
          cars (brand, model, plate_number)
        `)
        .eq("workshop_id", workshopId)
        .order("booking_date", { ascending: true });

      if (error) throw error;
      return data as Booking[];
    },
    enabled: !!workshopId,
  });
}

export function useCreateBooking() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (data: CreateBookingData) => {
      if (!user) throw new Error("يجب تسجيل الدخول");

      const { data: booking, error } = await supabase
        .from("bookings")
        .insert({
          ...data,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return booking;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["my-bookings"] });
      queryClient.invalidateQueries({ queryKey: ["workshop-bookings"] });
      toast({
        title: "تم الحجز",
        description: "تم حجز الموعد بنجاح وسيتم تأكيده قريباً",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useUpdateBookingStatus() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, status }: { id: string; status: BookingStatus }) => {
      const { error } = await supabase
        .from("bookings")
        .update({ status })
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["my-bookings"] });
      queryClient.invalidateQueries({ queryKey: ["workshop-bookings"] });
      toast({
        title: "تم التحديث",
        description: "تم تحديث حالة الحجز",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useCancelBooking() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (bookingId: string) => {
      const { error } = await supabase
        .from("bookings")
        .update({ status: "cancelled" })
        .eq("id", bookingId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["my-bookings"] });
      queryClient.invalidateQueries({ queryKey: ["workshop-bookings"] });
      toast({
        title: "تم الإلغاء",
        description: "تم إلغاء الحجز",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export const bookingStatusLabels: Record<BookingStatus, string> = {
  pending: "في الانتظار",
  confirmed: "مؤكد",
  completed: "مكتمل",
  cancelled: "ملغي",
};

export const bookingStatusColors: Record<BookingStatus, string> = {
  pending: "bg-warning/10 text-warning",
  confirmed: "bg-accent/10 text-accent",
  completed: "bg-primary/10 text-primary",
  cancelled: "bg-destructive/10 text-destructive",
};

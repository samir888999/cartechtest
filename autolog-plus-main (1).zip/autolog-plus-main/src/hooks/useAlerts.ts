import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

export type AlertType = 
  | "oil_change"
  | "tire_change"
  | "brake_service"
  | "insurance_renewal"
  | "technical_inspection"
  | "license_renewal"
  | "general_maintenance"
  | "custom";

export type AlertTriggerType = "date" | "mileage" | "both";

export interface Alert {
  id: string;
  car_id: string;
  user_id: string;
  alert_type: AlertType;
  custom_title: string | null;
  description: string | null;
  trigger_type: AlertTriggerType;
  trigger_date: string | null;
  trigger_mileage: number | null;
  remind_days_before: number;
  remind_km_before: number;
  is_active: boolean;
  is_completed: boolean;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreateAlertData {
  car_id: string;
  alert_type: AlertType;
  custom_title?: string;
  description?: string;
  trigger_type: AlertTriggerType;
  trigger_date?: string;
  trigger_mileage?: number;
  remind_days_before?: number;
  remind_km_before?: number;
}

export const alertTypeLabels: Record<AlertType, string> = {
  oil_change: "تغيير الزيت",
  tire_change: "تغيير العجلات",
  brake_service: "صيانة الفرامل",
  insurance_renewal: "تجديد التأمين",
  technical_inspection: "المراقبة التقنية",
  license_renewal: "تجديد الرخصة",
  general_maintenance: "صيانة عامة",
  custom: "تنبيه مخصص",
};

export const alertTypeIcons: Record<AlertType, string> = {
  oil_change: "🛢️",
  tire_change: "🔄",
  brake_service: "🔧",
  insurance_renewal: "📋",
  technical_inspection: "🔍",
  license_renewal: "🚘",
  general_maintenance: "⚙️",
  custom: "🎯",
};

export function useAlerts(carId?: string) {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["alerts", user?.id, carId],
    queryFn: async () => {
      let query = supabase
        .from("alerts")
        .select("*")
        .eq("is_completed", false)
        .order("trigger_date", { ascending: true });

      if (carId) {
        query = query.eq("car_id", carId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as Alert[];
    },
    enabled: !!user,
  });
}

export function useUpcomingAlerts() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["upcoming-alerts", user?.id],
    queryFn: async () => {
      const today = new Date().toISOString().split("T")[0];
      const { data, error } = await supabase
        .from("alerts")
        .select("*, cars(brand, model, plate_number)")
        .eq("is_active", true)
        .eq("is_completed", false)
        .or(`trigger_date.gte.${today},trigger_date.is.null`)
        .order("trigger_date", { ascending: true })
        .limit(10);

      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });
}

export function useCreateAlert() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (data: CreateAlertData) => {
      if (!user) throw new Error("يجب تسجيل الدخول");

      const { data: alert, error } = await supabase
        .from("alerts")
        .insert({
          ...data,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return alert;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["alerts"] });
      queryClient.invalidateQueries({ queryKey: ["upcoming-alerts"] });
      toast({
        title: "تمت الإضافة",
        description: "تم إضافة التنبيه بنجاح",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useCompleteAlert() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (alertId: string) => {
      const { error } = await supabase
        .from("alerts")
        .update({
          is_completed: true,
          completed_at: new Date().toISOString(),
        })
        .eq("id", alertId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["alerts"] });
      queryClient.invalidateQueries({ queryKey: ["upcoming-alerts"] });
      toast({
        title: "تم الإكمال",
        description: "تم تحديد التنبيه كمكتمل",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useDeleteAlert() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (alertId: string) => {
      const { error } = await supabase.from("alerts").delete().eq("id", alertId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["alerts"] });
      queryClient.invalidateQueries({ queryKey: ["upcoming-alerts"] });
      toast({
        title: "تم الحذف",
        description: "تم حذف التنبيه بنجاح",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Helper function to check if an alert is due soon
export function getAlertStatus(alert: Alert, currentMileage?: number) {
  const today = new Date();
  
  if (alert.trigger_type === "date" || alert.trigger_type === "both") {
    if (alert.trigger_date) {
      const triggerDate = new Date(alert.trigger_date);
      const daysUntil = Math.ceil((triggerDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysUntil < 0) return "overdue";
      if (daysUntil <= (alert.remind_days_before || 7)) return "warning";
    }
  }
  
  if (alert.trigger_type === "mileage" || alert.trigger_type === "both") {
    if (alert.trigger_mileage && currentMileage) {
      const kmUntil = alert.trigger_mileage - currentMileage;
      
      if (kmUntil < 0) return "overdue";
      if (kmUntil <= (alert.remind_km_before || 500)) return "warning";
    }
  }
  
  return "normal";
}

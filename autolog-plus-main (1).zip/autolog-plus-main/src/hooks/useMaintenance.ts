import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

export type MaintenanceType =
  | "oil_change"
  | "tire_rotation"
  | "tire_replacement"
  | "brake_service"
  | "filter_change"
  | "battery_replacement"
  | "general_service"
  | "inspection"
  | "other";

export interface MaintenanceRecord {
  id: string;
  car_id: string;
  user_id: string;
  maintenance_type: MaintenanceType;
  custom_type: string | null;
  description: string | null;
  mileage: number;
  cost: number | null;
  service_date: string;
  next_service_date: string | null;
  next_service_mileage: number | null;
  notes: string | null;
  invoice_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreateMaintenanceData {
  car_id: string;
  maintenance_type: MaintenanceType;
  custom_type?: string;
  description?: string;
  mileage: number;
  cost?: number;
  service_date: string;
  next_service_date?: string;
  next_service_mileage?: number;
  notes?: string;
}

export const maintenanceTypeLabels: Record<MaintenanceType, string> = {
  oil_change: "تغيير الزيت",
  tire_rotation: "تدوير العجلات",
  tire_replacement: "تغيير العجلات",
  brake_service: "صيانة الفرامل",
  filter_change: "تغيير الفلاتر",
  battery_replacement: "تغيير البطارية",
  general_service: "صيانة عامة",
  inspection: "فحص",
  other: "أخرى",
};

export function useMaintenanceRecords(carId?: string) {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["maintenance", user?.id, carId],
    queryFn: async () => {
      let query = supabase
        .from("maintenance_records")
        .select("*")
        .order("service_date", { ascending: false });

      if (carId) {
        query = query.eq("car_id", carId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as MaintenanceRecord[];
    },
    enabled: !!user,
  });
}

export function useCreateMaintenance() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (data: CreateMaintenanceData) => {
      if (!user) throw new Error("يجب تسجيل الدخول");

      const { data: record, error } = await supabase
        .from("maintenance_records")
        .insert({
          ...data,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return record;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["maintenance"] });
      toast({
        title: "تمت الإضافة",
        description: "تم إضافة سجل الصيانة بنجاح",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useDeleteMaintenance() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (recordId: string) => {
      const { error } = await supabase
        .from("maintenance_records")
        .delete()
        .eq("id", recordId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["maintenance"] });
      toast({
        title: "تم الحذف",
        description: "تم حذف سجل الصيانة",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

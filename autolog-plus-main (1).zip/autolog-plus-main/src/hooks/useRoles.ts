import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export type AppRole = "user" | "workshop" | "trader" | "admin";

export interface UserRole {
  id: string;
  user_id: string;
  role: AppRole;
  created_at: string;
}

export function useUserRole() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["user-role", user?.id],
    queryFn: async () => {
      if (!user) return null;
      
      const { data, error } = await supabase
        .from("user_roles")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) throw error;
      return data as UserRole | null;
    },
    enabled: !!user,
  });
}

export function useIsAdmin() {
  const { data: role, isLoading } = useUserRole();
  return {
    isAdmin: role?.role === "admin",
    isLoading,
  };
}

export function useIsWorkshop() {
  const { data: role, isLoading } = useUserRole();
  return {
    isWorkshop: role?.role === "workshop",
    isLoading,
  };
}

export function useIsTrader() {
  const { data: role, isLoading } = useUserRole();
  return {
    isTrader: role?.role === "trader",
    isLoading,
  };
}

export function useHasRole(requiredRole: AppRole) {
  const { data: role, isLoading } = useUserRole();
  return {
    hasRole: role?.role === requiredRole,
    isLoading,
  };
}

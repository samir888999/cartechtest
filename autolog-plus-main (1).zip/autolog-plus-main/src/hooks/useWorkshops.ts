import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

export interface Workshop {
  id: string;
  user_id: string;
  name: string;
  description: string | null;
  phone: string | null;
  address: string | null;
  city: string | null;
  latitude: number | null;
  longitude: number | null;
  logo_url: string | null;
  cover_url: string | null;
  is_verified: boolean;
  is_active: boolean;
  rating_average: number;
  rating_count: number;
  services: string[];
  working_hours: Record<string, string | number | boolean | null> | null;
  created_at: string;
  updated_at: string;
}

export interface CreateWorkshopData {
  name: string;
  description?: string;
  phone?: string;
  address?: string;
  city?: string;
  services?: string[];
}

export function useWorkshops() {
  return useQuery({
    queryKey: ["workshops"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("workshops")
        .select("*")
        .eq("is_active", true)
        .order("rating_average", { ascending: false });

      if (error) throw error;
      return data as Workshop[];
    },
  });
}

export function useWorkshop(workshopId: string | undefined) {
  return useQuery({
    queryKey: ["workshop", workshopId],
    queryFn: async () => {
      if (!workshopId) return null;
      const { data, error } = await supabase
        .from("workshops")
        .select("*")
        .eq("id", workshopId)
        .maybeSingle();

      if (error) throw error;
      return data as Workshop | null;
    },
    enabled: !!workshopId,
  });
}

export function useMyWorkshop() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["my-workshop", user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data, error } = await supabase
        .from("workshops")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) throw error;
      return data as Workshop | null;
    },
    enabled: !!user,
  });
}

export function useCreateWorkshop() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (data: CreateWorkshopData) => {
      if (!user) throw new Error("يجب تسجيل الدخول");

      const { data: workshop, error } = await supabase
        .from("workshops")
        .insert({
          ...data,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return workshop;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["workshops"] });
      queryClient.invalidateQueries({ queryKey: ["my-workshop"] });
      toast({
        title: "تمت الإضافة",
        description: "تم إنشاء الورشة بنجاح",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useUpdateWorkshop() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, working_hours, ...rest }: Partial<Workshop> & { id: string }) => {
      const updateData: Record<string, unknown> = { ...rest };
      if (working_hours !== undefined) {
        updateData.working_hours = working_hours;
      }
      const { data: workshop, error } = await supabase
        .from("workshops")
        .update(updateData)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return workshop;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["workshops"] });
      queryClient.invalidateQueries({ queryKey: ["workshop", variables.id] });
      queryClient.invalidateQueries({ queryKey: ["my-workshop"] });
      toast({
        title: "تم التحديث",
        description: "تم تحديث بيانات الورشة",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Workshop services list
export const workshopServices = [
  { value: "oil_change", label: "تغيير الزيت" },
  { value: "tire_service", label: "خدمات العجلات" },
  { value: "brake_service", label: "صيانة الفرامل" },
  { value: "engine_repair", label: "إصلاح المحرك" },
  { value: "electrical", label: "كهرباء السيارات" },
  { value: "ac_service", label: "صيانة المكيف" },
  { value: "body_work", label: "سمكرة ودهان" },
  { value: "inspection", label: "فحص شامل" },
  { value: "general_maintenance", label: "صيانة عامة" },
];

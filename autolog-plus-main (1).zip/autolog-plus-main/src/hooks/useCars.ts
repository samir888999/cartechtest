import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

export interface Car {
  id: string;
  user_id: string;
  brand: string;
  model: string;
  year: number;
  plate_number: string | null;
  vin_number: string | null;
  current_mileage: number;
  image_url: string | null;
  color: string | null;
  fuel_type: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreateCarData {
  brand: string;
  model: string;
  year: number;
  plate_number?: string;
  vin_number?: string;
  current_mileage: number;
  color?: string;
  fuel_type?: string;
}

export function useCars() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["cars", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("cars")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as Car[];
    },
    enabled: !!user,
  });
}

export function useCar(carId: string | undefined) {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["car", carId],
    queryFn: async () => {
      if (!carId) return null;
      const { data, error } = await supabase
        .from("cars")
        .select("*")
        .eq("id", carId)
        .maybeSingle();

      if (error) throw error;
      return data as Car | null;
    },
    enabled: !!user && !!carId,
  });
}

export function useCreateCar() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (data: CreateCarData) => {
      if (!user) throw new Error("يجب تسجيل الدخول");

      const { data: car, error } = await supabase
        .from("cars")
        .insert({
          ...data,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return car;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cars"] });
      toast({
        title: "تمت الإضافة",
        description: "تم إضافة السيارة بنجاح",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useUpdateCar() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...data }: Partial<Car> & { id: string }) => {
      const { data: car, error } = await supabase
        .from("cars")
        .update(data)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return car;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["cars"] });
      queryClient.invalidateQueries({ queryKey: ["car", variables.id] });
      toast({
        title: "تم التحديث",
        description: "تم تحديث بيانات السيارة",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useDeleteCar() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (carId: string) => {
      const { error } = await supabase.from("cars").delete().eq("id", carId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cars"] });
      toast({
        title: "تم الحذف",
        description: "تم حذف السيارة بنجاح",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

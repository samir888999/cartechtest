import { useState } from "react";
import { useNavigate } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { useCreateCar } from "@/hooks/useCars";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowRight, Car, Loader2 } from "lucide-react";

const carBrands = [
  "تويوتا",
  "هيونداي",
  "كيا",
  "نيسان",
  "هوندا",
  "مازدا",
  "فورد",
  "شيفروليه",
  "بي إم دبليو",
  "مرسيدس",
  "أودي",
  "فولكس واجن",
  "رينو",
  "بيجو",
  "ستروين",
  "سوزوكي",
  "ميتسوبيشي",
  "سكودا",
  "جيب",
  "أخرى",
];

const fuelTypes = [
  { value: "gasoline", label: "بنزين" },
  { value: "diesel", label: "ديزل" },
  { value: "electric", label: "كهربائي" },
  { value: "hybrid", label: "هجين" },
  { value: "lpg", label: "غاز" },
];

const currentYear = new Date().getFullYear();
const years = Array.from({ length: 40 }, (_, i) => currentYear - i);

export default function AddCar() {
  const navigate = useNavigate();
  const createCar = useCreateCar();

  const [brand, setBrand] = useState("");
  const [customBrand, setCustomBrand] = useState("");
  const [model, setModel] = useState("");
  const [year, setYear] = useState<number>(currentYear);
  const [plateNumber, setPlateNumber] = useState("");
  const [vinNumber, setVinNumber] = useState("");
  const [currentMileage, setCurrentMileage] = useState("");
  const [color, setColor] = useState("");
  const [fuelType, setFuelType] = useState("gasoline");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const finalBrand = brand === "أخرى" ? customBrand : brand;

    if (!finalBrand || !model || !year || !currentMileage) {
      return;
    }

    await createCar.mutateAsync({
      brand: finalBrand,
      model,
      year,
      plate_number: plateNumber || undefined,
      vin_number: vinNumber || undefined,
      current_mileage: parseInt(currentMileage),
      color: color || undefined,
      fuel_type: fuelType,
    });

    navigate("/cars");
  };

  return (
    <MainLayout>
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowRight className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">إضافة سيارة جديدة</h1>
            <p className="text-muted-foreground">أدخل بيانات سيارتك</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Car className="w-5 h-5" />
              بيانات السيارة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Brand & Model */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="brand">العلامة التجارية *</Label>
                  <Select value={brand} onValueChange={setBrand}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر العلامة" />
                    </SelectTrigger>
                    <SelectContent>
                      {carBrands.map((b) => (
                        <SelectItem key={b} value={b}>
                          {b}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {brand === "أخرى" && (
                    <Input
                      placeholder="أدخل اسم العلامة"
                      value={customBrand}
                      onChange={(e) => setCustomBrand(e.target.value)}
                      className="mt-2"
                    />
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="model">الموديل *</Label>
                  <Input
                    id="model"
                    placeholder="مثال: كامري، أكسنت..."
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    required
                  />
                </div>
              </div>

              {/* Year & Fuel */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="year">سنة الصنع *</Label>
                  <Select value={year.toString()} onValueChange={(v) => setYear(parseInt(v))}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر السنة" />
                    </SelectTrigger>
                    <SelectContent>
                      {years.map((y) => (
                        <SelectItem key={y} value={y.toString()}>
                          {y}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="fuelType">نوع الوقود</Label>
                  <Select value={fuelType} onValueChange={setFuelType}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر نوع الوقود" />
                    </SelectTrigger>
                    <SelectContent>
                      {fuelTypes.map((f) => (
                        <SelectItem key={f.value} value={f.value}>
                          {f.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Mileage & Color */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="mileage">الكيلومترات الحالية *</Label>
                  <Input
                    id="mileage"
                    type="number"
                    placeholder="مثال: 50000"
                    value={currentMileage}
                    onChange={(e) => setCurrentMileage(e.target.value)}
                    required
                    min="0"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="color">اللون</Label>
                  <Input
                    id="color"
                    placeholder="مثال: أبيض، أسود..."
                    value={color}
                    onChange={(e) => setColor(e.target.value)}
                  />
                </div>
              </div>

              {/* Plate & VIN */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="plate">رقم اللوحة</Label>
                  <Input
                    id="plate"
                    placeholder="مثال: أ ب ج 1234"
                    value={plateNumber}
                    onChange={(e) => setPlateNumber(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="vin">رقم الهيكل (VIN)</Label>
                  <Input
                    id="vin"
                    placeholder="17 حرف ورقم"
                    value={vinNumber}
                    onChange={(e) => setVinNumber(e.target.value)}
                    maxLength={17}
                    className="text-left"
                    dir="ltr"
                  />
                </div>
              </div>

              {/* Submit */}
              <div className="flex gap-3 pt-4">
                <Button
                  type="submit"
                  className="flex-1"
                  disabled={createCar.isPending}
                >
                  {createCar.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin ml-2" />
                      جاري الإضافة...
                    </>
                  ) : (
                    "إضافة السيارة"
                  )}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate(-1)}
                >
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}

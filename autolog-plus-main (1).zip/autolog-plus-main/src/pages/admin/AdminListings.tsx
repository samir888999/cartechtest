import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { useIsAdmin } from "@/hooks/useRoles";
import { useAllListings, useUpdateListingStatus } from "@/hooks/useCarListings";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Car, Check, X, Clock, ShoppingBag, Eye } from "lucide-react";

const statusLabels = {
  pending: "في الانتظار",
  approved: "مفعّل",
  rejected: "مرفوض",
  sold: "مباع",
};

const statusColors = {
  pending: "bg-warning/20 text-warning",
  approved: "bg-success/20 text-success",
  rejected: "bg-destructive/20 text-destructive",
  sold: "bg-muted text-muted-foreground",
};

export default function AdminListings() {
  const navigate = useNavigate();
  const { isAdmin, isLoading: roleLoading } = useIsAdmin();
  const [statusFilter, setStatusFilter] = useState("pending");
  const { data: listings, isLoading } = useAllListings(statusFilter);
  const updateStatus = useUpdateListingStatus();

  const [selectedListing, setSelectedListing] = useState<string | null>(null);
  const [actionType, setActionType] = useState<"approve" | "reject" | null>(null);
  const [adminNotes, setAdminNotes] = useState("");

  useEffect(() => {
    if (!roleLoading && !isAdmin) {
      navigate("/");
    }
  }, [isAdmin, roleLoading, navigate]);

  const handleAction = (listingId: string, action: "approve" | "reject") => {
    setSelectedListing(listingId);
    setActionType(action);
    setAdminNotes("");
  };

  const confirmAction = () => {
    if (!selectedListing || !actionType) return;

    updateStatus.mutate(
      {
        listingId: selectedListing,
        status: actionType === "approve" ? "approved" : "rejected",
        adminNotes: adminNotes || undefined,
      },
      {
        onSuccess: () => {
          setSelectedListing(null);
          setActionType(null);
          setAdminNotes("");
        },
      }
    );
  };

  if (roleLoading || isLoading) {
    return (
      <MainLayout>
        <div className="space-y-6">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-12 w-full" />
          <div className="space-y-3">
            <Skeleton className="h-40" />
            <Skeleton className="h-40" />
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!isAdmin) return null;

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">إدارة إعلانات السيارات</h1>
          <p className="text-muted-foreground">
            مراجعة وتفعيل إعلانات البيع
          </p>
        </div>

        <Tabs value={statusFilter} onValueChange={setStatusFilter}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="pending" className="gap-1">
              <Clock className="w-4 h-4" />
              في الانتظار
            </TabsTrigger>
            <TabsTrigger value="approved" className="gap-1">
              <Check className="w-4 h-4" />
              مفعّل
            </TabsTrigger>
            <TabsTrigger value="rejected" className="gap-1">
              <X className="w-4 h-4" />
              مرفوض
            </TabsTrigger>
            <TabsTrigger value="all" className="gap-1">
              <Eye className="w-4 h-4" />
              الكل
            </TabsTrigger>
          </TabsList>

          <TabsContent value={statusFilter} className="mt-4 space-y-4">
            {listings && listings.length > 0 ? (
              listings.map((listing) => (
                <Card key={listing.id}>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{listing.title}</CardTitle>
                        <p className="text-2xl font-bold text-primary mt-1">
                          {listing.price.toLocaleString()} درهم
                          {listing.is_negotiable && (
                            <span className="text-sm font-normal text-muted-foreground mr-2">
                              (قابل للتفاوض)
                            </span>
                          )}
                        </p>
                      </div>
                      <Badge className={statusColors[listing.status]}>
                        {statusLabels[listing.status]}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {/* Car Info */}
                    {listing.cars && (
                      <div className="flex items-center gap-2 text-sm">
                        <Car className="w-4 h-4 text-muted-foreground" />
                        <span>
                          {listing.cars.brand} {listing.cars.model} {listing.cars.year}
                        </span>
                        <span className="text-muted-foreground">
                          • {listing.cars.current_mileage.toLocaleString()} كم
                        </span>
                      </div>
                    )}

                    {listing.description && (
                      <p className="text-sm text-muted-foreground">
                        {listing.description}
                      </p>
                    )}

                    {/* Contact Info */}
                    <div className="flex flex-wrap gap-2 text-sm">
                      {listing.contact_phone && (
                        <a
                          href={`tel:${listing.contact_phone}`}
                          className="text-primary hover:underline"
                        >
                          📞 {listing.contact_phone}
                        </a>
                      )}
                      {listing.contact_whatsapp && (
                        <a
                          href={`https://wa.me/${listing.contact_whatsapp}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-success hover:underline"
                        >
                          💬 واتساب
                        </a>
                      )}
                    </div>

                    {listing.admin_notes && (
                      <p className="text-sm text-muted-foreground border-t pt-2">
                        <strong>ملاحظات الأدمن:</strong> {listing.admin_notes}
                      </p>
                    )}

                    {/* Actions for pending listings */}
                    {listing.status === "pending" && (
                      <div className="flex gap-2 pt-2 border-t">
                        <Button
                          size="sm"
                          className="gap-1"
                          onClick={() => handleAction(listing.id, "approve")}
                        >
                          <Check className="w-4 h-4" />
                          تفعيل
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1 text-destructive hover:text-destructive"
                          onClick={() => handleAction(listing.id, "reject")}
                        >
                          <X className="w-4 h-4" />
                          رفض
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-16">
                <ShoppingBag className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
                <h3 className="text-lg font-semibold mb-2">لا توجد إعلانات</h3>
                <p className="text-muted-foreground">
                  {statusFilter === "pending"
                    ? "لا توجد إعلانات في انتظار المراجعة"
                    : "لا توجد إعلانات في هذه الفئة"}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Confirmation Dialog */}
      <Dialog
        open={!!selectedListing && !!actionType}
        onOpenChange={() => {
          setSelectedListing(null);
          setActionType(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {actionType === "approve" ? "تفعيل الإعلان" : "رفض الإعلان"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-muted-foreground">
              {actionType === "approve"
                ? "هل تريد تفعيل هذا الإعلان ليظهر في سوق السيارات؟"
                : "هل تريد رفض هذا الإعلان؟ يمكنك إضافة سبب الرفض."}
            </p>
            <Textarea
              placeholder="ملاحظات (اختياري)"
              value={adminNotes}
              onChange={(e) => setAdminNotes(e.target.value)}
            />
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setSelectedListing(null);
                setActionType(null);
              }}
            >
              إلغاء
            </Button>
            <Button
              variant={actionType === "approve" ? "default" : "destructive"}
              onClick={confirmAction}
              disabled={updateStatus.isPending}
            >
              {updateStatus.isPending ? "جاري..." : "تأكيد"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}

import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { useIsAdmin } from "@/hooks/useRoles";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Bell, Calendar, Gauge, Car } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { alertTypeLabels, alertTypeIcons } from "@/hooks/useAlerts";

export default function AdminAlerts() {
  const navigate = useNavigate();
  const { isAdmin, isLoading: roleLoading } = useIsAdmin();

  const { data: alerts, isLoading } = useQuery({
    queryKey: ["admin-all-alerts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("alerts")
        .select(`
          *,
          cars(brand, model, plate_number, current_mileage)
        `)
        .eq("is_completed", false)
        .order("trigger_date", { ascending: true });

      if (error) throw error;
      return data;
    },
    enabled: isAdmin,
  });

  useEffect(() => {
    if (!roleLoading && !isAdmin) {
      navigate("/");
    }
  }, [isAdmin, roleLoading, navigate]);

  if (roleLoading || isLoading) {
    return (
      <MainLayout>
        <div className="space-y-6">
          <Skeleton className="h-8 w-48" />
          <div className="space-y-3">
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!isAdmin) return null;

  // Filter maintenance-related alerts
  const maintenanceAlerts = alerts?.filter((alert) =>
    ["oil_change", "tire_change", "brake_service", "general_maintenance"].includes(
      alert.alert_type
    )
  );

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">تنبيهات المستخدمين</h1>
          <p className="text-muted-foreground">
            {maintenanceAlerts?.length || 0} تنبيه صيانة نشط
          </p>
        </div>

        <div className="space-y-4">
          {maintenanceAlerts && maintenanceAlerts.length > 0 ? (
            maintenanceAlerts.map((alert) => {
              const icon = alertTypeIcons[alert.alert_type as keyof typeof alertTypeIcons];
              const label = alert.custom_title || alertTypeLabels[alert.alert_type as keyof typeof alertTypeLabels];
              const car = alert.cars as { brand: string; model: string; plate_number: string | null; current_mileage: number } | null;

              return (
                <Card key={alert.id}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <span className="text-2xl">{icon}</span>
                        {label}
                      </CardTitle>
                      <Badge variant="outline">
                        {alert.trigger_date
                          ? format(new Date(alert.trigger_date), "d MMMM yyyy", { locale: ar })
                          : "بدون تاريخ"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {/* Car Info */}
                    {car && (
                      <div className="flex items-center gap-2 text-sm">
                        <Car className="w-4 h-4 text-muted-foreground" />
                        <span>
                          {car.brand} {car.model}
                          {car.plate_number && ` - ${car.plate_number}`}
                        </span>
                      </div>
                    )}

                    {/* Trigger Info */}
                    <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                      {alert.trigger_date && (
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>
                            {format(new Date(alert.trigger_date), "d MMMM yyyy", {
                              locale: ar,
                            })}
                          </span>
                        </div>
                      )}
                      {alert.trigger_mileage && (
                        <div className="flex items-center gap-1">
                          <Gauge className="w-4 h-4" />
                          <span>{alert.trigger_mileage.toLocaleString()} كم</span>
                        </div>
                      )}
                      {car && (
                        <div className="flex items-center gap-1">
                          <span className="text-xs">العداد الحالي:</span>
                          <span>{car.current_mileage.toLocaleString()} كم</span>
                        </div>
                      )}
                    </div>

                    {alert.description && (
                      <p className="text-sm text-muted-foreground border-t pt-2">
                        {alert.description}
                      </p>
                    )}
                  </CardContent>
                </Card>
              );
            })
          ) : (
            <div className="text-center py-16">
              <Bell className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-semibold mb-2">لا توجد تنبيهات صيانة</h3>
              <p className="text-muted-foreground">
                ستظهر هنا تنبيهات المستخدمين المتعلقة بالصيانة
              </p>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}

import { useParams, useNavigate, Link } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { useCar, useDeleteCar, useUpdateCar } from "@/hooks/useCars";
import { useAlerts, useCompleteAlert, useDeleteAlert } from "@/hooks/useAlerts";
import { useMaintenanceRecords } from "@/hooks/useMaintenance";
import AlertCard from "@/components/alerts/AlertCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { 
  ArrowRight, 
  Car, 
  Gauge, 
  Calendar, 
  Fuel, 
  Palette,
  CreditCard,
  Bell,
  Wrench,
  Plus,
  Trash2,
  Edit2,
  Save,
  X
} from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { maintenanceTypeLabels } from "@/hooks/useMaintenance";

export default function CarDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const { data: car, isLoading } = useCar(id);
  const { data: alerts } = useAlerts(id);
  const { data: maintenance } = useMaintenanceRecords(id);
  const deleteCar = useDeleteCar();
  const updateCar = useUpdateCar();
  const completeAlert = useCompleteAlert();
  const deleteAlert = useDeleteAlert();

  const [editingMileage, setEditingMileage] = useState(false);
  const [newMileage, setNewMileage] = useState("");

  const handleDeleteCar = async () => {
    if (id) {
      await deleteCar.mutateAsync(id);
      navigate("/cars");
    }
  };

  const handleUpdateMileage = async () => {
    if (id && newMileage) {
      await updateCar.mutateAsync({
        id,
        current_mileage: parseInt(newMileage),
      });
      setEditingMileage(false);
    }
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="space-y-4">
          <Skeleton className="h-10 w-32" />
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-32 w-full" />
        </div>
      </MainLayout>
    );
  }

  if (!car) {
    return (
      <MainLayout>
        <div className="text-center py-16">
          <Car className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
          <h2 className="text-xl font-semibold mb-2">السيارة غير موجودة</h2>
          <Link to="/cars">
            <Button>العودة للسيارات</Button>
          </Link>
        </div>
      </MainLayout>
    );
  }

  const fuelTypeLabels: Record<string, string> = {
    gasoline: "بنزين",
    diesel: "ديزل",
    electric: "كهربائي",
    hybrid: "هجين",
    lpg: "غاز",
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowRight className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold">
              {car.brand} {car.model}
            </h1>
            <p className="text-muted-foreground">{car.plate_number || "بدون لوحة"}</p>
          </div>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="icon" className="text-destructive">
                <Trash2 className="w-5 h-5" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>حذف السيارة</AlertDialogTitle>
                <AlertDialogDescription>
                  هل أنت متأكد من حذف هذه السيارة؟ سيتم حذف جميع سجلات الصيانة والتنبيهات المرتبطة بها.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>إلغاء</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteCar} className="bg-destructive text-destructive-foreground">
                  حذف
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>

        {/* Car Info Card */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              {/* Car Image */}
              <div className="w-24 h-24 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                <Car className="w-12 h-12 text-primary/50" />
              </div>

              {/* Info Grid */}
              <div className="flex-1 grid grid-cols-2 sm:grid-cols-3 gap-4">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">السنة</p>
                    <p className="font-medium">{car.year}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">الكيلومترات</p>
                    <div className="flex items-center gap-1">
                      {editingMileage ? (
                        <div className="flex items-center gap-1">
                          <Input
                            type="number"
                            value={newMileage}
                            onChange={(e) => setNewMileage(e.target.value)}
                            className="h-7 w-24 text-sm"
                            placeholder={car.current_mileage.toString()}
                          />
                          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={handleUpdateMileage}>
                            <Save className="w-3 h-3" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setEditingMileage(false)}>
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      ) : (
                        <>
                          <p className="font-medium">{car.current_mileage.toLocaleString()} كم</p>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-6 w-6"
                            onClick={() => {
                              setNewMileage(car.current_mileage.toString());
                              setEditingMileage(true);
                            }}
                          >
                            <Edit2 className="w-3 h-3" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {car.fuel_type && (
                  <div className="flex items-center gap-2">
                    <Fuel className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">الوقود</p>
                      <p className="font-medium">{fuelTypeLabels[car.fuel_type] || car.fuel_type}</p>
                    </div>
                  </div>
                )}

                {car.color && (
                  <div className="flex items-center gap-2">
                    <Palette className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">اللون</p>
                      <p className="font-medium">{car.color}</p>
                    </div>
                  </div>
                )}

                {car.vin_number && (
                  <div className="flex items-center gap-2 col-span-2">
                    <CreditCard className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">رقم الهيكل</p>
                      <p className="font-medium text-xs" dir="ltr">{car.vin_number}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Alerts Section */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Bell className="w-5 h-5" />
              التنبيهات ({alerts?.length || 0})
            </CardTitle>
            <Link to={`/alerts/new?car=${id}`}>
              <Button size="sm" variant="outline" className="gap-1">
                <Plus className="w-4 h-4" />
                إضافة تنبيه
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-3">
            {alerts && alerts.length > 0 ? (
              alerts.map((alert) => (
                <AlertCard
                  key={alert.id}
                  alert={alert}
                  currentMileage={car.current_mileage}
                  onComplete={(id) => completeAlert.mutate(id)}
                  onDelete={(id) => deleteAlert.mutate(id)}
                />
              ))
            ) : (
              <div className="text-center py-6">
                <Bell className="w-10 h-10 mx-auto text-muted-foreground/50 mb-2" />
                <p className="text-sm text-muted-foreground">لا توجد تنبيهات</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Maintenance History */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Wrench className="w-5 h-5" />
              سجل الصيانة ({maintenance?.length || 0})
            </CardTitle>
            <Link to={`/maintenance/new?car=${id}`}>
              <Button size="sm" variant="outline" className="gap-1">
                <Plus className="w-4 h-4" />
                إضافة صيانة
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {maintenance && maintenance.length > 0 ? (
              <div className="space-y-3">
                {maintenance.slice(0, 5).map((record) => (
                  <div
                    key={record.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                  >
                    <div>
                      <p className="font-medium">
                        {maintenanceTypeLabels[record.maintenance_type]}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(record.service_date), "d MMMM yyyy", { locale: ar })}
                        {" • "}
                        {record.mileage.toLocaleString()} كم
                      </p>
                    </div>
                    {record.cost && (
                      <p className="font-semibold text-primary">
                        {record.cost.toLocaleString()} د.ج
                      </p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <Wrench className="w-10 h-10 mx-auto text-muted-foreground/50 mb-2" />
                <p className="text-sm text-muted-foreground">لا توجد سجلات صيانة</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}

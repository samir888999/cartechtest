import { Link } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { useCars } from "@/hooks/useCars";
import { useUpcomingAlerts, useCompleteAlert, useDeleteAlert } from "@/hooks/useAlerts";
import CarCard from "@/components/cars/CarCard";
import AlertCard from "@/components/alerts/AlertCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Car, Bell, Plus, ArrowLeft, Gauge, Wrench, AlertTriangle } from "lucide-react";

export default function Dashboard() {
  const { data: cars, isLoading: carsLoading } = useCars();
  const { data: upcomingAlerts, isLoading: alertsLoading } = useUpcomingAlerts();
  const completeAlert = useCompleteAlert();
  const deleteAlert = useDeleteAlert();

  // Stats
  const totalCars = cars?.length || 0;
  const totalAlerts = upcomingAlerts?.length || 0;
  const urgentAlerts = upcomingAlerts?.filter(a => {
    const today = new Date();
    if (a.trigger_date) {
      const triggerDate = new Date(a.trigger_date);
      const daysUntil = Math.ceil((triggerDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return daysUntil <= 7;
    }
    return false;
  }).length || 0;

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Welcome */}
        <div>
          <h1 className="text-2xl font-bold">مرحباً بك 👋</h1>
          <p className="text-muted-foreground">تابع حالة سياراتك والتنبيهات القادمة</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Car className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalCars}</p>
                <p className="text-sm text-muted-foreground">سيارة</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center">
                <Bell className="w-6 h-6 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalAlerts}</p>
                <p className="text-sm text-muted-foreground">تنبيه نشط</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">{urgentAlerts}</p>
                <p className="text-sm text-muted-foreground">تنبيه عاجل</p>
              </div>
            </CardContent>
          </Card>

          <Card className="col-span-2 lg:col-span-1">
            <CardContent className="p-4">
              <Link to="/cars/new">
                <Button className="w-full h-full min-h-[60px] gap-2">
                  <Plus className="w-5 h-5" />
                  إضافة سيارة
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Cars Section */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Car className="w-5 h-5" />
              سياراتي
            </CardTitle>
            <Link to="/cars">
              <Button variant="ghost" size="sm" className="gap-1">
                عرض الكل
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-3">
            {carsLoading ? (
              <>
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
              </>
            ) : cars && cars.length > 0 ? (
              cars.slice(0, 3).map((car) => (
                <CarCard key={car.id} car={car} />
              ))
            ) : (
              <div className="text-center py-8">
                <Car className="w-12 h-12 mx-auto text-muted-foreground/50 mb-3" />
                <p className="text-muted-foreground mb-4">لا توجد سيارات بعد</p>
                <Link to="/cars/new">
                  <Button className="gap-2">
                    <Plus className="w-4 h-4" />
                    أضف سيارتك الأولى
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Alerts Section */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Bell className="w-5 h-5" />
              التنبيهات القادمة
            </CardTitle>
            <Link to="/alerts">
              <Button variant="ghost" size="sm" className="gap-1">
                عرض الكل
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-3">
            {alertsLoading ? (
              <>
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
              </>
            ) : upcomingAlerts && upcomingAlerts.length > 0 ? (
              upcomingAlerts.slice(0, 5).map((alert) => (
                <AlertCard
                  key={alert.id}
                  alert={alert}
                  showCarInfo
                  onComplete={(id) => completeAlert.mutate(id)}
                  onDelete={(id) => deleteAlert.mutate(id)}
                />
              ))
            ) : (
              <div className="text-center py-8">
                <Bell className="w-12 h-12 mx-auto text-muted-foreground/50 mb-3" />
                <p className="text-muted-foreground">لا توجد تنبيهات قادمة</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}

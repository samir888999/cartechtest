import MainLayout from "@/components/layout/MainLayout";
import { useUpcomingAlerts, useCompleteAlert, useDeleteAlert } from "@/hooks/useAlerts";
import AlertCard from "@/components/alerts/AlertCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Bell, Plus } from "lucide-react";
import { Link } from "react-router-dom";

export default function Alerts() {
  const { data: alerts, isLoading } = useUpcomingAlerts();
  const completeAlert = useCompleteAlert();
  const deleteAlert = useDeleteAlert();

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">التنبيهات</h1>
            <p className="text-muted-foreground">{alerts?.length || 0} تنبيه نشط</p>
          </div>
          <Link to="/alerts/new">
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              إضافة تنبيه
            </Button>
          </Link>
        </div>

        <div className="space-y-3">
          {isLoading ? (
            <>
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
            </>
          ) : alerts && alerts.length > 0 ? (
            alerts.map((alert) => (
              <AlertCard
                key={alert.id}
                alert={alert}
                showCarInfo
                onComplete={(id) => completeAlert.mutate(id)}
                onDelete={(id) => deleteAlert.mutate(id)}
              />
            ))
          ) : (
            <div className="text-center py-16">
              <Bell className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-semibold mb-2">لا توجد تنبيهات</h3>
              <p className="text-muted-foreground mb-6">أضف تنبيهات لتذكيرك بمواعيد الصيانة</p>
              <Link to="/alerts/new">
                <Button className="gap-2">
                  <Plus className="w-4 h-4" />
                  إضافة تنبيه
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}

import { Link } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { useCars, useDeleteCar } from "@/hooks/useCars";
import { useAlerts } from "@/hooks/useAlerts";
import CarCard from "@/components/cars/CarCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Car, Plus } from "lucide-react";

export default function Cars() {
  const { data: cars, isLoading } = useCars();
  const { data: alerts } = useAlerts();

  // Count alerts per car
  const alertCountByCar = alerts?.reduce((acc, alert) => {
    acc[alert.car_id] = (acc[alert.car_id] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">سياراتي</h1>
            <p className="text-muted-foreground">
              {cars?.length || 0} سيارة مسجلة
            </p>
          </div>
          <Link to="/cars/new">
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              إضافة سيارة
            </Button>
          </Link>
        </div>

        {/* Cars List */}
        <div className="space-y-3">
          {isLoading ? (
            <>
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
            </>
          ) : cars && cars.length > 0 ? (
            cars.map((car) => (
              <CarCard
                key={car.id}
                car={car}
                alertCount={alertCountByCar[car.id]}
              />
            ))
          ) : (
            <div className="text-center py-16">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Car className="w-10 h-10 text-primary/50" />
              </div>
              <h3 className="text-lg font-semibold mb-2">لا توجد سيارات بعد</h3>
              <p className="text-muted-foreground mb-6">
                ابدأ بإضافة سيارتك الأولى لتتبع حالتها وصيانتها
              </p>
              <Link to="/cars/new">
                <Button className="gap-2">
                  <Plus className="w-4 h-4" />
                  أضف سيارتك الأولى
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}

import MainLayout from "@/components/layout/MainLayout";
import { useMarketplaceListings } from "@/hooks/useCarListings";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ShoppingBag, Car, Gauge, Calendar, Phone, MessageCircle } from "lucide-react";
import { Link } from "react-router-dom";

export default function Marketplace() {
  const { data: listings, isLoading } = useMarketplaceListings();

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">سوق السيارات</h1>
            <p className="text-muted-foreground">
              {listings?.length || 0} سيارة معروضة للبيع
            </p>
          </div>
          <Link to="/marketplace/sell">
            <Button className="gap-2">
              <ShoppingBag className="w-4 h-4" />
              عرض سيارتي للبيع
            </Button>
          </Link>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {isLoading ? (
            <>
              <Skeleton className="h-64" />
              <Skeleton className="h-64" />
              <Skeleton className="h-64" />
              <Skeleton className="h-64" />
            </>
          ) : listings && listings.length > 0 ? (
            listings.map((listing) => (
              <Card key={listing.id} className="overflow-hidden">
                {/* Car Image */}
                <div className="aspect-video bg-muted relative">
                  {listing.image_url || listing.cars?.image_url ? (
                    <img
                      src={listing.image_url || listing.cars?.image_url}
                      alt={listing.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Car className="w-16 h-16 text-muted-foreground/30" />
                    </div>
                  )}
                  {listing.is_negotiable && (
                    <Badge className="absolute top-2 right-2 bg-primary">
                      قابل للتفاوض
                    </Badge>
                  )}
                </div>

                <CardContent className="p-4 space-y-3">
                  <div>
                    <h3 className="font-semibold text-lg">{listing.title}</h3>
                    <p className="text-2xl font-bold text-primary">
                      {listing.price.toLocaleString()} درهم
                    </p>
                  </div>

                  {listing.cars && (
                    <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Car className="w-4 h-4" />
                        <span>
                          {listing.cars.brand} {listing.cars.model}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>{listing.cars.year}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Gauge className="w-4 h-4" />
                        <span>{listing.cars.current_mileage.toLocaleString()} كم</span>
                      </div>
                    </div>
                  )}

                  {listing.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {listing.description}
                    </p>
                  )}

                  {/* Contact Buttons */}
                  <div className="flex gap-2 pt-2">
                    {listing.contact_phone && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 gap-1"
                        asChild
                      >
                        <a href={`tel:${listing.contact_phone}`}>
                          <Phone className="w-4 h-4" />
                          اتصال
                        </a>
                      </Button>
                    )}
                    {listing.contact_whatsapp && (
                      <Button
                        size="sm"
                        className="flex-1 gap-1 bg-success hover:bg-success/90"
                        asChild
                      >
                        <a
                          href={`https://wa.me/${listing.contact_whatsapp}`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <MessageCircle className="w-4 h-4" />
                          واتساب
                        </a>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-16">
              <ShoppingBag className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-semibold mb-2">لا توجد سيارات معروضة</h3>
              <p className="text-muted-foreground mb-6">
                كن أول من يعرض سيارته للبيع
              </p>
              <Link to="/marketplace/sell">
                <Button className="gap-2">
                  <ShoppingBag className="w-4 h-4" />
                  عرض سيارتي للبيع
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}

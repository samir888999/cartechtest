import { useState } from "react";
import { Link } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { useWorkshops, workshopServices } from "@/hooks/useWorkshops";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Wrench, 
  Search, 
  Star, 
  MapPin, 
  Phone, 
  CheckCircle,
  ChevronLeft
} from "lucide-react";

export default function Workshops() {
  const { data: workshops, isLoading } = useWorkshops();
  const [searchQuery, setSearchQuery] = useState("");

  const filteredWorkshops = workshops?.filter((workshop) =>
    workshop.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    workshop.city?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold">الورشات</h1>
          <p className="text-muted-foreground">
            ابحث عن ورشة موثوقة واحجز موعدك
          </p>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="ابحث عن ورشة أو مدينة..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10"
          />
        </div>

        {/* Workshops List */}
        <div className="space-y-4">
          {isLoading ? (
            <>
              <Skeleton className="h-40 w-full" />
              <Skeleton className="h-40 w-full" />
              <Skeleton className="h-40 w-full" />
            </>
          ) : filteredWorkshops && filteredWorkshops.length > 0 ? (
            filteredWorkshops.map((workshop) => (
              <Link key={workshop.id} to={`/workshops/${workshop.id}`}>
                <Card className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      {/* Logo */}
                      <div className="w-20 h-20 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                        {workshop.logo_url ? (
                          <img
                            src={workshop.logo_url}
                            alt={workshop.name}
                            className="w-full h-full object-cover rounded-xl"
                          />
                        ) : (
                          <Wrench className="w-8 h-8 text-primary" />
                        )}
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold truncate">{workshop.name}</h3>
                              {workshop.is_verified && (
                                <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                              )}
                            </div>
                            
                            {/* Rating */}
                            <div className="flex items-center gap-1 mt-1">
                              <Star className="w-4 h-4 fill-warning text-warning" />
                              <span className="text-sm font-medium">
                                {workshop.rating_average.toFixed(1)}
                              </span>
                              <span className="text-sm text-muted-foreground">
                                ({workshop.rating_count} تقييم)
                              </span>
                            </div>
                          </div>
                          
                          <ChevronLeft className="w-5 h-5 text-muted-foreground shrink-0" />
                        </div>

                        {/* Location */}
                        {(workshop.city || workshop.address) && (
                          <div className="flex items-center gap-1 mt-2 text-sm text-muted-foreground">
                            <MapPin className="w-3 h-3" />
                            <span className="truncate">
                              {workshop.city}
                              {workshop.address && ` - ${workshop.address}`}
                            </span>
                          </div>
                        )}

                        {/* Services */}
                        {workshop.services && workshop.services.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {workshop.services.slice(0, 3).map((service) => {
                              const serviceInfo = workshopServices.find(s => s.value === service);
                              return (
                                <Badge key={service} variant="secondary" className="text-xs">
                                  {serviceInfo?.label || service}
                                </Badge>
                              );
                            })}
                            {workshop.services.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{workshop.services.length - 3}
                              </Badge>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))
          ) : (
            <div className="text-center py-16">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Wrench className="w-10 h-10 text-primary/50" />
              </div>
              <h3 className="text-lg font-semibold mb-2">لا توجد ورشات</h3>
              <p className="text-muted-foreground">
                {searchQuery 
                  ? "لم نجد ورشات مطابقة لبحثك"
                  : "لم يتم تسجيل أي ورشات بعد"
                }
              </p>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}

import MainLayout from "@/components/layout/MainLayout";
import { useMyBookings, useCancelBooking, bookingStatusLabels, bookingStatusColors } from "@/hooks/useBookings";
import { workshopServices } from "@/hooks/useWorkshops";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { 
  Calendar, 
  Clock, 
  Wrench,
  Car,
  MapPin,
  Phone,
  X
} from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function MyBookings() {
  const { data: bookings, isLoading } = useMyBookings();
  const cancelBooking = useCancelBooking();

  const upcomingBookings = bookings?.filter(b => 
    b.status === "pending" || b.status === "confirmed"
  ) || [];
  
  const pastBookings = bookings?.filter(b => 
    b.status === "completed" || b.status === "cancelled"
  ) || [];

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold">حجوزاتي</h1>
          <p className="text-muted-foreground">
            {upcomingBookings.length} حجز قادم
          </p>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        ) : bookings && bookings.length > 0 ? (
          <div className="space-y-6">
            {/* Upcoming Bookings */}
            {upcomingBookings.length > 0 && (
              <div className="space-y-4">
                <h2 className="font-semibold text-lg">الحجوزات القادمة</h2>
                {upcomingBookings.map((booking) => {
                  const serviceInfo = workshopServices.find(s => s.value === booking.service_type);
                  return (
                    <Card key={booking.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <div>
                            <h3 className="font-semibold">{booking.workshops?.name}</h3>
                            <Badge className={bookingStatusColors[booking.status]}>
                              {bookingStatusLabels[booking.status]}
                            </Badge>
                          </div>
                          
                          {booking.status === "pending" && (
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <X className="w-4 h-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>إلغاء الحجز</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    هل أنت متأكد من إلغاء هذا الحجز؟
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>لا، إبقاء</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => cancelBooking.mutate(booking.id)}
                                    className="bg-destructive hover:bg-destructive/90"
                                  >
                                    نعم، إلغاء
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          )}
                        </div>

                        <div className="space-y-2 text-sm">
                          {/* Service */}
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Wrench className="w-4 h-4" />
                            {serviceInfo?.label || booking.service_type}
                          </div>

                          {/* Car */}
                          {booking.cars && (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Car className="w-4 h-4" />
                              {booking.cars.brand} {booking.cars.model}
                              {booking.cars.plate_number && ` - ${booking.cars.plate_number}`}
                            </div>
                          )}

                          {/* Date & Time */}
                          <div className="flex items-center gap-4">
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Calendar className="w-4 h-4" />
                              {format(new Date(booking.booking_date), "d MMMM yyyy", { locale: ar })}
                            </div>
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Clock className="w-4 h-4" />
                              {booking.booking_time.slice(0, 5)}
                            </div>
                          </div>

                          {/* Workshop contact */}
                          {booking.workshops?.phone && (
                            <a
                              href={`tel:${booking.workshops.phone}`}
                              className="flex items-center gap-2 text-primary hover:underline"
                            >
                              <Phone className="w-4 h-4" />
                              {booking.workshops.phone}
                            </a>
                          )}
                        </div>

                        {booking.notes && (
                          <p className="mt-3 text-sm text-muted-foreground bg-muted p-2 rounded">
                            {booking.notes}
                          </p>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}

            {/* Past Bookings */}
            {pastBookings.length > 0 && (
              <div className="space-y-4">
                <h2 className="font-semibold text-lg text-muted-foreground">الحجوزات السابقة</h2>
                {pastBookings.map((booking) => {
                  const serviceInfo = workshopServices.find(s => s.value === booking.service_type);
                  return (
                    <Card key={booking.id} className="opacity-70">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-medium">{booking.workshops?.name}</h3>
                          <Badge className={bookingStatusColors[booking.status]}>
                            {bookingStatusLabels[booking.status]}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span>{serviceInfo?.label || booking.service_type}</span>
                          <span>•</span>
                          <span>{format(new Date(booking.booking_date), "d MMMM yyyy", { locale: ar })}</span>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
              <Calendar className="w-10 h-10 text-primary/50" />
            </div>
            <h3 className="text-lg font-semibold mb-2">لا توجد حجوزات</h3>
            <p className="text-muted-foreground">
              لم تقم بأي حجز بعد. ابحث عن ورشة واحجز موعدك!
            </p>
          </div>
        )}
      </div>
    </MainLayout>
  );
}

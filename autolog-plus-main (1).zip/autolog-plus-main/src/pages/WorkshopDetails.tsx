import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { useWorkshop, workshopServices } from "@/hooks/useWorkshops";
import { useCars } from "@/hooks/useCars";
import { useCreateBooking } from "@/hooks/useBookings";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  Wrench, 
  Star, 
  MapPin, 
  Phone, 
  CheckCircle,
  Calendar,
  Clock,
  ArrowRight,
  Car
} from "lucide-react";

export default function WorkshopDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: workshop, isLoading } = useWorkshop(id);
  const { data: cars } = useCars();
  const createBooking = useCreateBooking();

  const [bookingOpen, setBookingOpen] = useState(false);
  const [selectedCar, setSelectedCar] = useState("");
  const [selectedService, setSelectedService] = useState("");
  const [bookingDate, setBookingDate] = useState("");
  const [bookingTime, setBookingTime] = useState("");
  const [notes, setNotes] = useState("");

  const handleBooking = async () => {
    if (!id || !selectedCar || !selectedService || !bookingDate || !bookingTime) return;

    await createBooking.mutateAsync({
      workshop_id: id,
      car_id: selectedCar,
      service_type: selectedService,
      booking_date: bookingDate,
      booking_time: bookingTime,
      notes: notes || undefined,
    });

    setBookingOpen(false);
    // Reset form
    setSelectedCar("");
    setSelectedService("");
    setBookingDate("");
    setBookingTime("");
    setNotes("");
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="space-y-6">
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-32 w-full" />
        </div>
      </MainLayout>
    );
  }

  if (!workshop) {
    return (
      <MainLayout>
        <div className="text-center py-16">
          <h2 className="text-xl font-semibold mb-2">الورشة غير موجودة</h2>
          <Button onClick={() => navigate("/workshops")}>
            العودة للورشات
          </Button>
        </div>
      </MainLayout>
    );
  }

  const availableServices = workshop.services?.map(service => {
    const serviceInfo = workshopServices.find(s => s.value === service);
    return serviceInfo || { value: service, label: service };
  }) || workshopServices;

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Back Button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate("/workshops")}
          className="gap-2"
        >
          <ArrowRight className="w-4 h-4" />
          العودة
        </Button>

        {/* Header Card */}
        <Card>
          <CardContent className="p-6">
            <div className="flex gap-4">
              {/* Logo */}
              <div className="w-24 h-24 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                {workshop.logo_url ? (
                  <img
                    src={workshop.logo_url}
                    alt={workshop.name}
                    className="w-full h-full object-cover rounded-xl"
                  />
                ) : (
                  <Wrench className="w-10 h-10 text-primary" />
                )}
              </div>

              {/* Info */}
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h1 className="text-xl font-bold">{workshop.name}</h1>
                  {workshop.is_verified && (
                    <CheckCircle className="w-5 h-5 text-accent" />
                  )}
                </div>

                {/* Rating */}
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex items-center gap-1">
                    <Star className="w-5 h-5 fill-warning text-warning" />
                    <span className="font-semibold">{workshop.rating_average.toFixed(1)}</span>
                  </div>
                  <span className="text-muted-foreground">
                    ({workshop.rating_count} تقييم)
                  </span>
                </div>

                {/* Contact Info */}
                <div className="space-y-1 text-sm">
                  {workshop.phone && (
                    <a 
                      href={`tel:${workshop.phone}`}
                      className="flex items-center gap-2 text-muted-foreground hover:text-foreground"
                    >
                      <Phone className="w-4 h-4" />
                      {workshop.phone}
                    </a>
                  )}
                  {(workshop.city || workshop.address) && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      {workshop.city}
                      {workshop.address && ` - ${workshop.address}`}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {workshop.description && (
              <p className="mt-4 text-muted-foreground">{workshop.description}</p>
            )}
          </CardContent>
        </Card>

        {/* Services */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">الخدمات المتوفرة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {workshop.services && workshop.services.length > 0 ? (
                workshop.services.map((service) => {
                  const serviceInfo = workshopServices.find(s => s.value === service);
                  return (
                    <Badge key={service} variant="secondary">
                      {serviceInfo?.label || service}
                    </Badge>
                  );
                })
              ) : (
                <p className="text-muted-foreground">جميع الخدمات متوفرة</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Book Button */}
        <Dialog open={bookingOpen} onOpenChange={setBookingOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="w-full gap-2">
              <Calendar className="w-5 h-5" />
              احجز موعدك الآن
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>حجز موعد في {workshop.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              {/* Select Car */}
              <div className="space-y-2">
                <label className="text-sm font-medium">اختر السيارة</label>
                <Select value={selectedCar} onValueChange={setSelectedCar}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر سيارتك" />
                  </SelectTrigger>
                  <SelectContent>
                    {cars?.map((car) => (
                      <SelectItem key={car.id} value={car.id}>
                        <div className="flex items-center gap-2">
                          <Car className="w-4 h-4" />
                          {car.brand} {car.model} - {car.plate_number || car.year}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Select Service */}
              <div className="space-y-2">
                <label className="text-sm font-medium">نوع الخدمة</label>
                <Select value={selectedService} onValueChange={setSelectedService}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر الخدمة" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableServices.map((service) => (
                      <SelectItem key={service.value} value={service.value}>
                        {service.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Date */}
              <div className="space-y-2">
                <label className="text-sm font-medium">التاريخ</label>
                <Input
                  type="date"
                  value={bookingDate}
                  onChange={(e) => setBookingDate(e.target.value)}
                  min={new Date().toISOString().split("T")[0]}
                />
              </div>

              {/* Time */}
              <div className="space-y-2">
                <label className="text-sm font-medium">الوقت</label>
                <Input
                  type="time"
                  value={bookingTime}
                  onChange={(e) => setBookingTime(e.target.value)}
                />
              </div>

              {/* Notes */}
              <div className="space-y-2">
                <label className="text-sm font-medium">ملاحظات (اختياري)</label>
                <Textarea
                  placeholder="أي تفاصيل إضافية..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>

              <Button
                className="w-full"
                onClick={handleBooking}
                disabled={
                  !selectedCar || 
                  !selectedService || 
                  !bookingDate || 
                  !bookingTime ||
                  createBooking.isPending
                }
              >
                {createBooking.isPending ? "جاري الحجز..." : "تأكيد الحجز"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </MainLayout>
  );
}

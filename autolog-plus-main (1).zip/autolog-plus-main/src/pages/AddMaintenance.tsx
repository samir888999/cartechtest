import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { useCars } from "@/hooks/useCars";
import { useCreateMaintenance, MaintenanceType, maintenanceTypeLabels } from "@/hooks/useMaintenance";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowRight, Wrench, Calendar, DollarSign, Gauge } from "lucide-react";

export default function AddMaintenance() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const preselectedCarId = searchParams.get("car");
  
  const { data: cars } = useCars();
  const createMaintenance = useCreateMaintenance();

  const [formData, setFormData] = useState({
    car_id: preselectedCarId || "",
    maintenance_type: "" as MaintenanceType | "",
    custom_type: "",
    service_date: new Date().toISOString().split("T")[0],
    mileage: "",
    cost: "",
    description: "",
    notes: "",
    next_service_date: "",
    next_service_mileage: "",
  });

  useEffect(() => {
    if (preselectedCarId) {
      setFormData(prev => ({ ...prev, car_id: preselectedCarId }));
    }
  }, [preselectedCarId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.car_id || !formData.maintenance_type || !formData.mileage) return;

    await createMaintenance.mutateAsync({
      car_id: formData.car_id,
      maintenance_type: formData.maintenance_type as MaintenanceType,
      custom_type: formData.maintenance_type === "other" ? formData.custom_type : undefined,
      service_date: formData.service_date,
      mileage: parseInt(formData.mileage),
      cost: formData.cost ? parseFloat(formData.cost) : undefined,
      description: formData.description || undefined,
      notes: formData.notes || undefined,
      next_service_date: formData.next_service_date || undefined,
      next_service_mileage: formData.next_service_mileage ? parseInt(formData.next_service_mileage) : undefined,
    });

    navigate(preselectedCarId ? `/cars/${preselectedCarId}` : "/cars");
  };

  const maintenanceTypes: MaintenanceType[] = [
    "oil_change",
    "tire_rotation",
    "tire_replacement",
    "brake_service",
    "filter_change",
    "battery_replacement",
    "general_service",
    "inspection",
    "other",
  ];

  return (
    <MainLayout>
      <div className="space-y-6 max-w-lg mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
          >
            <ArrowRight className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">إضافة سجل صيانة</h1>
            <p className="text-muted-foreground">تسجيل عملية صيانة جديدة</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Car Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">اختر السيارة</CardTitle>
            </CardHeader>
            <CardContent>
              <Select
                value={formData.car_id}
                onValueChange={(value) => setFormData({ ...formData, car_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر سيارة" />
                </SelectTrigger>
                <SelectContent>
                  {cars?.map((car) => (
                    <SelectItem key={car.id} value={car.id}>
                      {car.brand} {car.model} - {car.plate_number || car.year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* Maintenance Type */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Wrench className="w-5 h-5" />
                نوع الصيانة
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select
                value={formData.maintenance_type}
                onValueChange={(value) => setFormData({ ...formData, maintenance_type: value as MaintenanceType })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر نوع الصيانة" />
                </SelectTrigger>
                <SelectContent>
                  {maintenanceTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {maintenanceTypeLabels[type]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {formData.maintenance_type === "other" && (
                <Input
                  placeholder="نوع الصيانة المخصص"
                  value={formData.custom_type}
                  onChange={(e) => setFormData({ ...formData, custom_type: e.target.value })}
                  required
                />
              )}

              <Textarea
                placeholder="وصف الصيانة (اختياري)"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </CardContent>
          </Card>

          {/* Details */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">تفاصيل الصيانة</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  تاريخ الصيانة
                </label>
                <Input
                  type="date"
                  value={formData.service_date}
                  onChange={(e) => setFormData({ ...formData, service_date: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Gauge className="w-4 h-4" />
                  الكيلومترات الحالية
                </label>
                <Input
                  type="number"
                  placeholder="مثال: 45000"
                  value={formData.mileage}
                  onChange={(e) => setFormData({ ...formData, mileage: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <DollarSign className="w-4 h-4" />
                  التكلفة (اختياري)
                </label>
                <Input
                  type="number"
                  placeholder="مثال: 500"
                  value={formData.cost}
                  onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                />
              </div>

              <Textarea
                placeholder="ملاحظات إضافية (اختياري)"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              />
            </CardContent>
          </Card>

          {/* Next Service */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">الصيانة القادمة (اختياري)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">تاريخ الصيانة القادمة</label>
                <Input
                  type="date"
                  value={formData.next_service_date}
                  onChange={(e) => setFormData({ ...formData, next_service_date: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">عند الكيلومترات</label>
                <Input
                  type="number"
                  placeholder="مثال: 50000"
                  value={formData.next_service_mileage}
                  onChange={(e) => setFormData({ ...formData, next_service_mileage: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>

          {/* Submit */}
          <Button
            type="submit"
            size="lg"
            className="w-full"
            disabled={!formData.car_id || !formData.maintenance_type || !formData.mileage || createMaintenance.isPending}
          >
            {createMaintenance.isPending ? "جاري الحفظ..." : "حفظ سجل الصيانة"}
          </Button>
        </form>
      </div>
    </MainLayout>
  );
}

import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { useCars } from "@/hooks/useCars";
import { useCreateAlert, AlertType, AlertTriggerType, alertTypeLabels } from "@/hooks/useAlerts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowRight, Bell, Calendar, Gauge } from "lucide-react";

export default function AddAlert() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const preselectedCarId = searchParams.get("car");
  
  const { data: cars } = useCars();
  const createAlert = useCreateAlert();

  const [formData, setFormData] = useState({
    car_id: preselectedCarId || "",
    alert_type: "" as AlertType | "",
    custom_title: "",
    description: "",
    trigger_type: "date" as AlertTriggerType,
    trigger_date: "",
    trigger_mileage: "",
    remind_days_before: "7",
    remind_km_before: "500",
  });

  useEffect(() => {
    if (preselectedCarId) {
      setFormData(prev => ({ ...prev, car_id: preselectedCarId }));
    }
  }, [preselectedCarId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.car_id || !formData.alert_type) return;

    await createAlert.mutateAsync({
      car_id: formData.car_id,
      alert_type: formData.alert_type as AlertType,
      custom_title: formData.alert_type === "custom" ? formData.custom_title : undefined,
      description: formData.description || undefined,
      trigger_type: formData.trigger_type,
      trigger_date: formData.trigger_date || undefined,
      trigger_mileage: formData.trigger_mileage ? parseInt(formData.trigger_mileage) : undefined,
      remind_days_before: parseInt(formData.remind_days_before),
      remind_km_before: parseInt(formData.remind_km_before),
    });

    navigate(preselectedCarId ? `/cars/${preselectedCarId}` : "/alerts");
  };

  const alertTypes: AlertType[] = [
    "oil_change",
    "tire_change",
    "brake_service",
    "insurance_renewal",
    "technical_inspection",
    "license_renewal",
    "general_maintenance",
    "custom",
  ];

  return (
    <MainLayout>
      <div className="space-y-6 max-w-lg mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
          >
            <ArrowRight className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">إضافة تنبيه</h1>
            <p className="text-muted-foreground">إنشاء تنبيه جديد لسيارتك</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Car Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">اختر السيارة</CardTitle>
            </CardHeader>
            <CardContent>
              <Select
                value={formData.car_id}
                onValueChange={(value) => setFormData({ ...formData, car_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر سيارة" />
                </SelectTrigger>
                <SelectContent>
                  {cars?.map((car) => (
                    <SelectItem key={car.id} value={car.id}>
                      {car.brand} {car.model} - {car.plate_number || car.year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* Alert Type */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Bell className="w-5 h-5" />
                نوع التنبيه
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select
                value={formData.alert_type}
                onValueChange={(value) => setFormData({ ...formData, alert_type: value as AlertType })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر نوع التنبيه" />
                </SelectTrigger>
                <SelectContent>
                  {alertTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {alertTypeLabels[type]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {formData.alert_type === "custom" && (
                <Input
                  placeholder="عنوان التنبيه المخصص"
                  value={formData.custom_title}
                  onChange={(e) => setFormData({ ...formData, custom_title: e.target.value })}
                  required
                />
              )}

              <Textarea
                placeholder="وصف التنبيه (اختياري)"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </CardContent>
          </Card>

          {/* Trigger Type */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">متى يتم التنبيه؟</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select
                value={formData.trigger_type}
                onValueChange={(value) => setFormData({ ...formData, trigger_type: value as AlertTriggerType })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="date">حسب التاريخ</SelectItem>
                  <SelectItem value="mileage">حسب الكيلومترات</SelectItem>
                  <SelectItem value="both">التاريخ والكيلومترات معاً</SelectItem>
                </SelectContent>
              </Select>

              {(formData.trigger_type === "date" || formData.trigger_type === "both") && (
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    تاريخ التنبيه
                  </label>
                  <Input
                    type="date"
                    value={formData.trigger_date}
                    onChange={(e) => setFormData({ ...formData, trigger_date: e.target.value })}
                    required={formData.trigger_type === "date" || formData.trigger_type === "both"}
                  />
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">ذكرني قبل</span>
                    <Input
                      type="number"
                      className="w-20"
                      value={formData.remind_days_before}
                      onChange={(e) => setFormData({ ...formData, remind_days_before: e.target.value })}
                    />
                    <span className="text-sm text-muted-foreground">يوم</span>
                  </div>
                </div>
              )}

              {(formData.trigger_type === "mileage" || formData.trigger_type === "both") && (
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Gauge className="w-4 h-4" />
                    عند الكيلومترات
                  </label>
                  <Input
                    type="number"
                    placeholder="مثال: 50000"
                    value={formData.trigger_mileage}
                    onChange={(e) => setFormData({ ...formData, trigger_mileage: e.target.value })}
                    required={formData.trigger_type === "mileage" || formData.trigger_type === "both"}
                  />
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">ذكرني قبل</span>
                    <Input
                      type="number"
                      className="w-24"
                      value={formData.remind_km_before}
                      onChange={(e) => setFormData({ ...formData, remind_km_before: e.target.value })}
                    />
                    <span className="text-sm text-muted-foreground">كم</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Submit */}
          <Button
            type="submit"
            size="lg"
            className="w-full"
            disabled={!formData.car_id || !formData.alert_type || createAlert.isPending}
          >
            {createAlert.isPending ? "جاري الإضافة..." : "إضافة التنبيه"}
          </Button>
        </form>
      </div>
    </MainLayout>
  );
}

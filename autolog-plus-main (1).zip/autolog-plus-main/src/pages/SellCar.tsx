import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { useCars } from "@/hooks/useCars";
import { useCreateListing, useMyListings } from "@/hooks/useCarListings";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Car, ShoppingBag, Upload, X, Loader2 } from "lucide-react";

const statusLabels = {
  pending: "في انتظار الموافقة",
  approved: "معروضة للبيع",
  rejected: "مرفوض",
  sold: "مباعة",
};

const statusColors = {
  pending: "bg-warning/20 text-warning",
  approved: "bg-success/20 text-success",
  rejected: "bg-destructive/20 text-destructive",
  sold: "bg-muted text-muted-foreground",
};

export default function SellCar() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: cars, isLoading: carsLoading } = useCars();
  const { data: myListings, isLoading: listingsLoading } = useMyListings();
  const createListing = useCreateListing();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    car_id: "",
    title: "",
    description: "",
    price: "",
    is_negotiable: true,
    contact_phone: "",
    contact_whatsapp: "",
  });

  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setImageFile(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const uploadImage = async (): Promise<string | null> => {
    if (!imageFile || !user) return null;

    const fileExt = imageFile.name.split(".").pop();
    const fileName = `${user.id}/${Date.now()}.${fileExt}`;

    const { error } = await supabase.storage
      .from("car-images")
      .upload(fileName, imageFile);

    if (error) {
      console.error("Upload error:", error);
      return null;
    }

    const { data: urlData } = supabase.storage
      .from("car-images")
      .getPublicUrl(fileName);

    return urlData.publicUrl;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.car_id || !formData.title || !formData.price) return;

    setUploading(true);
    let imageUrl: string | undefined;

    if (imageFile) {
      const uploadedUrl = await uploadImage();
      if (uploadedUrl) {
        imageUrl = uploadedUrl;
      }
    }

    createListing.mutate(
      {
        car_id: formData.car_id,
        title: formData.title,
        description: formData.description || undefined,
        price: parseFloat(formData.price),
        is_negotiable: formData.is_negotiable,
        contact_phone: formData.contact_phone || undefined,
        contact_whatsapp: formData.contact_whatsapp || undefined,
        image_url: imageUrl,
      },
      {
        onSuccess: () => {
          setFormData({
            car_id: "",
            title: "",
            description: "",
            price: "",
            is_negotiable: true,
            contact_phone: "",
            contact_whatsapp: "",
          });
          removeImage();
          setUploading(false);
        },
        onError: () => {
          setUploading(false);
        },
      }
    );
  };

  const selectedCar = cars?.find((c) => c.id === formData.car_id);

  // Check which cars are already listed
  const listedCarIds = myListings?.map((l) => l.car_id) || [];
  const availableCars = cars?.filter((c) => !listedCarIds.includes(c.id)) || [];

  if (carsLoading || listingsLoading) {
    return (
      <MainLayout>
        <div className="space-y-6">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-64" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">عرض سيارتي للبيع</h1>
          <p className="text-muted-foreground">
            أضف إعلانك وسيتم مراجعته من قبل الإدارة
          </p>
        </div>

        {/* My Listings */}
        {myListings && myListings.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">إعلاناتي</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {myListings.map((listing) => (
                <div
                  key={listing.id}
                  className="flex items-center justify-between p-3 bg-muted rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    {listing.image_url && (
                      <img
                        src={listing.image_url}
                        alt={listing.title}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                    )}
                    <div>
                      <p className="font-medium">{listing.title}</p>
                      <p className="text-sm text-muted-foreground">
                        {listing.price.toLocaleString()} درهم
                      </p>
                    </div>
                  </div>
                  <Badge className={statusColors[listing.status]}>
                    {statusLabels[listing.status]}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* New Listing Form */}
        {availableCars.length > 0 ? (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">إضافة إعلان جديد</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Select Car */}
                <div className="space-y-2">
                  <Label>اختر السيارة</Label>
                  <Select
                    value={formData.car_id}
                    onValueChange={(value) =>
                      setFormData({ ...formData, car_id: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر السيارة" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableCars.map((car) => (
                        <SelectItem key={car.id} value={car.id}>
                          {car.brand} {car.model} {car.year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Selected Car Info */}
                {selectedCar && (
                  <div className="p-3 bg-muted rounded-lg flex items-center gap-3">
                    <Car className="w-8 h-8 text-muted-foreground" />
                    <div>
                      <p className="font-medium">
                        {selectedCar.brand} {selectedCar.model} {selectedCar.year}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {selectedCar.current_mileage.toLocaleString()} كم
                        {selectedCar.color && ` • ${selectedCar.color}`}
                      </p>
                    </div>
                  </div>
                )}

                {/* Image Upload */}
                <div className="space-y-2">
                  <Label>صورة السيارة</Label>
                  <div className="flex items-center gap-4">
                    {imagePreview ? (
                      <div className="relative">
                        <img
                          src={imagePreview}
                          alt="Preview"
                          className="w-32 h-32 object-cover rounded-lg border"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute -top-2 -right-2 w-6 h-6"
                          onClick={removeImage}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ) : (
                      <div
                        onClick={() => fileInputRef.current?.click()}
                        className="w-32 h-32 border-2 border-dashed rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-primary transition-colors"
                      >
                        <Upload className="w-8 h-8 text-muted-foreground mb-2" />
                        <span className="text-sm text-muted-foreground">رفع صورة</span>
                      </div>
                    )}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="hidden"
                    />
                  </div>
                </div>

                {/* Title */}
                <div className="space-y-2">
                  <Label>عنوان الإعلان</Label>
                  <Input
                    placeholder="مثال: سيارة نظيفة جداً بحالة ممتازة"
                    value={formData.title}
                    onChange={(e) =>
                      setFormData({ ...formData, title: e.target.value })
                    }
                    required
                  />
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label>وصف الإعلان</Label>
                  <Textarea
                    placeholder="أضف تفاصيل عن السيارة..."
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    rows={4}
                  />
                </div>

                {/* Price */}
                <div className="space-y-2">
                  <Label>السعر (درهم)</Label>
                  <Input
                    type="number"
                    placeholder="50000"
                    value={formData.price}
                    onChange={(e) =>
                      setFormData({ ...formData, price: e.target.value })
                    }
                    required
                  />
                </div>

                {/* Negotiable */}
                <div className="flex items-center justify-between">
                  <Label>قابل للتفاوض</Label>
                  <Switch
                    checked={formData.is_negotiable}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, is_negotiable: checked })
                    }
                  />
                </div>

                {/* Contact Info */}
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>رقم الهاتف</Label>
                    <Input
                      type="tel"
                      placeholder="0612345678"
                      value={formData.contact_phone}
                      onChange={(e) =>
                        setFormData({ ...formData, contact_phone: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>رقم الواتساب</Label>
                    <Input
                      type="tel"
                      placeholder="212612345678"
                      value={formData.contact_whatsapp}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          contact_whatsapp: e.target.value,
                        })
                      }
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={createListing.isPending || uploading}
                >
                  {createListing.isPending || uploading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin ml-2" />
                      جاري الإرسال...
                    </>
                  ) : (
                    "إرسال للمراجعة"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        ) : cars && cars.length > 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <ShoppingBag className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">
                جميع سياراتك معروضة للبيع بالفعل
              </p>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="text-center py-8">
              <Car className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground mb-4">
                يجب إضافة سيارة أولاً قبل عرضها للبيع
              </p>
              <Button onClick={() => navigate("/cars/new")}>إضافة سيارة</Button>
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}

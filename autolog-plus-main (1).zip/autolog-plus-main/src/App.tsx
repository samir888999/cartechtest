import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";

// Pages
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Cars from "./pages/Cars";
import AddCar from "./pages/AddCar";
import CarDetails from "./pages/CarDetails";
import Alerts from "./pages/Alerts";
import AddAlert from "./pages/AddAlert";
import AddMaintenance from "./pages/AddMaintenance";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";

// Workshop pages
import Workshops from "./pages/Workshops";
import WorkshopDetails from "./pages/WorkshopDetails";
import MyBookings from "./pages/MyBookings";

// Marketplace pages
import Marketplace from "./pages/Marketplace";
import SellCar from "./pages/SellCar";

// Admin pages
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminAlerts from "./pages/admin/AdminAlerts";
import AdminListings from "./pages/admin/AdminListings";

const queryClient = new QueryClient();

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (user) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
      <Route path="/register" element={<PublicRoute><Register /></PublicRoute>} />

      {/* Protected Routes */}
      <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/cars" element={<ProtectedRoute><Cars /></ProtectedRoute>} />
      <Route path="/cars/new" element={<ProtectedRoute><AddCar /></ProtectedRoute>} />
      <Route path="/cars/:id" element={<ProtectedRoute><CarDetails /></ProtectedRoute>} />
      <Route path="/alerts" element={<ProtectedRoute><Alerts /></ProtectedRoute>} />
      <Route path="/alerts/new" element={<ProtectedRoute><AddAlert /></ProtectedRoute>} />
      <Route path="/maintenance/new" element={<ProtectedRoute><AddMaintenance /></ProtectedRoute>} />
      <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />

      {/* Workshop Routes */}
      <Route path="/workshops" element={<ProtectedRoute><Workshops /></ProtectedRoute>} />
      <Route path="/workshops/:id" element={<ProtectedRoute><WorkshopDetails /></ProtectedRoute>} />
      <Route path="/my-bookings" element={<ProtectedRoute><MyBookings /></ProtectedRoute>} />

      {/* Marketplace Routes */}
      <Route path="/marketplace" element={<ProtectedRoute><Marketplace /></ProtectedRoute>} />
      <Route path="/marketplace/sell" element={<ProtectedRoute><SellCar /></ProtectedRoute>} />

      {/* Admin Routes */}
      <Route path="/admin" element={<ProtectedRoute><AdminDashboard /></ProtectedRoute>} />
      <Route path="/admin/alerts" element={<ProtectedRoute><AdminAlerts /></ProtectedRoute>} />
      <Route path="/admin/listings" element={<ProtectedRoute><AdminListings /></ProtectedRoute>} />

      {/* 404 */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;

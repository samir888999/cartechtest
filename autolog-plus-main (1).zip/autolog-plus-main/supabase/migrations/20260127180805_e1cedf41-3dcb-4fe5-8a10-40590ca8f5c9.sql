-- Create user roles enum
CREATE TYPE public.app_role AS ENUM ('user', 'workshop', 'trader', 'admin');

-- Create user_roles table (separate from profiles for security)
CREATE TABLE public.user_roles (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL DEFAULT 'user',
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    UNIQUE (user_id, role)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Security definer function to check user roles (prevents RLS recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Function to get user's primary role
CREATE OR REPLACE FUNCTION public.get_user_role(_user_id uuid)
RETURNS app_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role
  FROM public.user_roles
  WHERE user_id = _user_id
  ORDER BY 
    CASE role 
      WHEN 'admin' THEN 1 
      WHEN 'workshop' THEN 2 
      WHEN 'trader' THEN 3 
      ELSE 4 
    END
  LIMIT 1
$$;

-- RLS policies for user_roles
CREATE POLICY "Users can view their own roles"
ON public.user_roles
FOR SELECT
USING (auth.uid() = user_id);

-- Only admins can manage roles
CREATE POLICY "Admins can manage all roles"
ON public.user_roles
FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Auto-assign default 'user' role on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    -- Create profile
    INSERT INTO public.profiles (user_id, full_name)
    VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name');
    
    -- Assign default user role
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'user');
    
    RETURN NEW;
END;
$$;

-- Create workshops table
CREATE TABLE public.workshops (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    name text NOT NULL,
    description text,
    phone text,
    address text,
    city text,
    latitude numeric,
    longitude numeric,
    logo_url text,
    cover_url text,
    is_verified boolean NOT NULL DEFAULT false,
    is_active boolean NOT NULL DEFAULT true,
    rating_average numeric DEFAULT 0,
    rating_count integer DEFAULT 0,
    services text[] DEFAULT '{}',
    working_hours jsonb DEFAULT '{}',
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on workshops
ALTER TABLE public.workshops ENABLE ROW LEVEL SECURITY;

-- Workshops RLS policies
CREATE POLICY "Anyone can view active workshops"
ON public.workshops
FOR SELECT
USING (is_active = true);

CREATE POLICY "Workshop owners can update their workshop"
ON public.workshops
FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users with workshop role can insert"
ON public.workshops
FOR INSERT
WITH CHECK (
    auth.uid() = user_id 
    AND public.has_role(auth.uid(), 'workshop')
);

-- Create workshop_reviews table
CREATE TABLE public.workshop_reviews (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    workshop_id uuid REFERENCES public.workshops(id) ON DELETE CASCADE NOT NULL,
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment text,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    UNIQUE (workshop_id, user_id)
);

-- Enable RLS on workshop_reviews
ALTER TABLE public.workshop_reviews ENABLE ROW LEVEL SECURITY;

-- Reviews RLS policies
CREATE POLICY "Anyone can view reviews"
ON public.workshop_reviews
FOR SELECT
USING (true);

CREATE POLICY "Users can insert their own reviews"
ON public.workshop_reviews
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own reviews"
ON public.workshop_reviews
FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own reviews"
ON public.workshop_reviews
FOR DELETE
USING (auth.uid() = user_id);

-- Create bookings table
CREATE TABLE public.bookings (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    workshop_id uuid REFERENCES public.workshops(id) ON DELETE CASCADE NOT NULL,
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    car_id uuid REFERENCES public.cars(id) ON DELETE CASCADE NOT NULL,
    service_type text NOT NULL,
    booking_date date NOT NULL,
    booking_time time NOT NULL,
    status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
    notes text,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on bookings
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

-- Bookings RLS policies
CREATE POLICY "Users can view their own bookings"
ON public.bookings
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Workshops can view bookings for their workshop"
ON public.bookings
FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM public.workshops w 
        WHERE w.id = workshop_id AND w.user_id = auth.uid()
    )
);

CREATE POLICY "Users can insert their own bookings"
ON public.bookings
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own bookings"
ON public.bookings
FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Workshops can update bookings for their workshop"
ON public.bookings
FOR UPDATE
USING (
    EXISTS (
        SELECT 1 FROM public.workshops w 
        WHERE w.id = workshop_id AND w.user_id = auth.uid()
    )
);

-- Triggers for updated_at
CREATE TRIGGER update_workshops_updated_at
BEFORE UPDATE ON public.workshops
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_workshop_reviews_updated_at
BEFORE UPDATE ON public.workshop_reviews
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_bookings_updated_at
BEFORE UPDATE ON public.bookings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Function to update workshop rating
CREATE OR REPLACE FUNCTION public.update_workshop_rating()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    UPDATE public.workshops
    SET 
        rating_average = (
            SELECT COALESCE(AVG(rating), 0)
            FROM public.workshop_reviews
            WHERE workshop_id = COALESCE(NEW.workshop_id, OLD.workshop_id)
        ),
        rating_count = (
            SELECT COUNT(*)
            FROM public.workshop_reviews
            WHERE workshop_id = COALESCE(NEW.workshop_id, OLD.workshop_id)
        )
    WHERE id = COALESCE(NEW.workshop_id, OLD.workshop_id);
    
    RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE TRIGGER update_workshop_rating_trigger
AFTER INSERT OR UPDATE OR DELETE ON public.workshop_reviews
FOR EACH ROW
EXECUTE FUNCTION public.update_workshop_rating();
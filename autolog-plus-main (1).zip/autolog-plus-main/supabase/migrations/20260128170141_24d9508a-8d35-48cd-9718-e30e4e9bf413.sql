-- Function to auto-assign admin role for specific email
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    -- Create profile
    INSERT INTO public.profiles (user_id, full_name)
    VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name');
    
    -- Assign admin role for specific email, otherwise default user role
    IF NEW.email = 'a_mine26@hotmail.com' THEN
        INSERT INTO public.user_roles (user_id, role)
        VALUES (NEW.id, 'admin');
    ELSE
        INSERT INTO public.user_roles (user_id, role)
        VALUES (NEW.id, 'user');
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- RLS policies for admin access to profiles
CREATE POLICY "Admins can view all profiles"
ON public.profiles
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all profiles"
ON public.profiles
FOR UPDATE
USING (has_role(auth.uid(), 'admin'));

-- RLS policies for admin access to cars
CREATE POLICY "Admins can view all cars"
ON public.cars
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all cars"
ON public.cars
FOR UPDATE
USING (has_role(auth.uid(), 'admin'));

-- RLS policies for admin access to alerts
CREATE POLICY "Admins can view all alerts"
ON public.alerts
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all alerts"
ON public.alerts
FOR UPDATE
USING (has_role(auth.uid(), 'admin'));

-- RLS policies for admin access to maintenance records
CREATE POLICY "Admins can view all maintenance records"
ON public.maintenance_records
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

-- RLS policies for admin access to bookings
CREATE POLICY "Admins can view all bookings"
ON public.bookings
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all bookings"
ON public.bookings
FOR UPDATE
USING (has_role(auth.uid(), 'admin'));

-- RLS policies for admin access to workshops
CREATE POLICY "Admins can view all workshops"
ON public.workshops
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all workshops"
ON public.workshops
FOR UPDATE
USING (has_role(auth.uid(), 'admin'));
-- Create profiles table for user information
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    full_name TEXT,
    phone TEXT,
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view their own profile"
ON public.profiles FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile"
ON public.profiles FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile"
ON public.profiles FOR UPDATE
USING (auth.uid() = user_id);

-- Create cars table
CREATE TABLE public.cars (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    brand TEXT NOT NULL,
    model TEXT NOT NULL,
    year INTEGER NOT NULL,
    plate_number TEXT,
    vin_number TEXT,
    current_mileage INTEGER NOT NULL DEFAULT 0,
    image_url TEXT,
    color TEXT,
    fuel_type TEXT DEFAULT 'gasoline',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on cars
ALTER TABLE public.cars ENABLE ROW LEVEL SECURITY;

-- Cars policies
CREATE POLICY "Users can view their own cars"
ON public.cars FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own cars"
ON public.cars FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own cars"
ON public.cars FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own cars"
ON public.cars FOR DELETE
USING (auth.uid() = user_id);

-- Create maintenance types enum
CREATE TYPE public.maintenance_type AS ENUM (
    'oil_change',
    'tire_rotation',
    'tire_replacement',
    'brake_service',
    'filter_change',
    'battery_replacement',
    'general_service',
    'inspection',
    'other'
);

-- Create maintenance records table
CREATE TABLE public.maintenance_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    car_id UUID REFERENCES public.cars(id) ON DELETE CASCADE NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    maintenance_type maintenance_type NOT NULL,
    custom_type TEXT,
    description TEXT,
    mileage INTEGER NOT NULL,
    cost DECIMAL(10, 2),
    service_date DATE NOT NULL,
    next_service_date DATE,
    next_service_mileage INTEGER,
    notes TEXT,
    invoice_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on maintenance_records
ALTER TABLE public.maintenance_records ENABLE ROW LEVEL SECURITY;

-- Maintenance records policies
CREATE POLICY "Users can view their own maintenance records"
ON public.maintenance_records FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own maintenance records"
ON public.maintenance_records FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own maintenance records"
ON public.maintenance_records FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own maintenance records"
ON public.maintenance_records FOR DELETE
USING (auth.uid() = user_id);

-- Create alert types enum
CREATE TYPE public.alert_type AS ENUM (
    'oil_change',
    'tire_change',
    'brake_service',
    'insurance_renewal',
    'technical_inspection',
    'license_renewal',
    'general_maintenance',
    'custom'
);

-- Create alert trigger type enum
CREATE TYPE public.alert_trigger_type AS ENUM (
    'date',
    'mileage',
    'both'
);

-- Create alerts table
CREATE TABLE public.alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    car_id UUID REFERENCES public.cars(id) ON DELETE CASCADE NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    alert_type alert_type NOT NULL,
    custom_title TEXT,
    description TEXT,
    trigger_type alert_trigger_type NOT NULL DEFAULT 'date',
    trigger_date DATE,
    trigger_mileage INTEGER,
    remind_days_before INTEGER DEFAULT 7,
    remind_km_before INTEGER DEFAULT 500,
    is_active BOOLEAN NOT NULL DEFAULT true,
    is_completed BOOLEAN NOT NULL DEFAULT false,
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on alerts
ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;

-- Alerts policies
CREATE POLICY "Users can view their own alerts"
ON public.alerts FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own alerts"
ON public.alerts FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own alerts"
ON public.alerts FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own alerts"
ON public.alerts FOR DELETE
USING (auth.uid() = user_id);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_profiles_updated_at
BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_cars_updated_at
BEFORE UPDATE ON public.cars
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_maintenance_records_updated_at
BEFORE UPDATE ON public.maintenance_records
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_alerts_updated_at
BEFORE UPDATE ON public.alerts
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Create function to auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (user_id, full_name)
    VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for auto-creating profile
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
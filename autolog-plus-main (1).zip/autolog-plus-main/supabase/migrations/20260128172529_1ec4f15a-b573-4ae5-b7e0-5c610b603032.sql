-- Create car_listings table for marketplace
CREATE TABLE public.car_listings (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    car_id UUID NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
    user_id UUID NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    price NUMERIC NOT NULL,
    is_negotiable BOOLEAN DEFAULT true,
    contact_phone TEXT,
    contact_whatsapp TEXT,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'sold')),
    admin_notes TEXT,
    approved_at TIMESTAMP WITH TIME ZONE,
    approved_by UUID,
    views_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.car_listings ENABLE ROW LEVEL SECURITY;

-- Users can view their own listings
CREATE POLICY "Users can view their own listings"
ON public.car_listings
FOR SELECT
USING (auth.uid() = user_id);

-- Users can insert their own listings
CREATE POLICY "Users can insert their own listings"
ON public.car_listings
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Users can update their own pending listings
CREATE POLICY "Users can update their own listings"
ON public.car_listings
FOR UPDATE
USING (auth.uid() = user_id AND status = 'pending');

-- Users can delete their own listings
CREATE POLICY "Users can delete their own listings"
ON public.car_listings
FOR DELETE
USING (auth.uid() = user_id);

-- Anyone can view approved listings
CREATE POLICY "Anyone can view approved listings"
ON public.car_listings
FOR SELECT
USING (status = 'approved');

-- Admins can view all listings
CREATE POLICY "Admins can view all listings"
ON public.car_listings
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

-- Admins can update all listings
CREATE POLICY "Admins can update all listings"
ON public.car_listings
FOR UPDATE
USING (has_role(auth.uid(), 'admin'));

-- Create index for faster queries
CREATE INDEX idx_car_listings_status ON public.car_listings(status);
CREATE INDEX idx_car_listings_user_id ON public.car_listings(user_id);

-- Update trigger for updated_at
CREATE TRIGGER update_car_listings_updated_at
BEFORE UPDATE ON public.car_listings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();